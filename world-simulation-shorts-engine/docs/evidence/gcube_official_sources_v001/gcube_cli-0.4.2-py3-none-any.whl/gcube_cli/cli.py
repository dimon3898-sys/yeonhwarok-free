from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from typing import Literal

import click

from gcube_cli import __version__
from gcube_cli._group import OrderedGroup
from gcube_cli.commands.auth import auth
from gcube_cli.commands.completion import completion
from gcube_cli.commands.configure import config
from gcube_cli.commands.credential import credential
from gcube_cli.commands.gpu import gpu
from gcube_cli.commands.point import point
from gcube_cli.commands.resource import resource
from gcube_cli.commands.skill import skill
from gcube_cli.commands.storage import storage
from gcube_cli.commands.team import team
from gcube_cli.commands.workload import workload
from gcube_cli.config import Config
from gcube_cli.update_check import check_for_update


@dataclass
class GcubeContext:
    """CLI 실행 컨텍스트. 모든 서브커맨드에서 ctx.obj로 접근."""

    platform_url: str
    output: Literal["table", "json", "yaml"]
    debug: bool
    token: str | None = None
    team_id: int = 0
    """Team context resolved from GCUBE_TEAM (0 = personal / unified view).

    Deliberately NOT persisted to config — see PBI-023 §10. Both ways of setting
    a team context (``--team`` flag, ``GCUBE_TEAM`` env) are visible at call time,
    so there is no hidden mode to inspect with a separate command.
    """


@click.group(cls=OrderedGroup)
@click.version_option(
    __version__,
    "--version",
    "-V",
    message="gcube %(version)s",
    help="Show the version and exit",
)
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "yaml"]),
    default="table",
    show_default=True,
    envvar="GCUBE_OUTPUT",
    help="Output format",
)
@click.option(
    "--debug",
    is_flag=True,
    default=False,
    help="Enable HTTP debug logging",
    hidden=True,
)
@click.pass_context
def cli(
    ctx: click.Context,
    output: str,
    debug: bool,
) -> None:
    """gcube - AI GPU Cloud Platform CLI"""
    cfg = Config.load()

    # GCUBE_PLATFORM_URL env var > config file > default
    eff_url = os.environ.get("GCUBE_PLATFORM_URL") or cfg.platform_url

    eff_output = output
    if ctx.get_parameter_source("output").name == "DEFAULT":  # type: ignore[union-attr]
        eff_output = cfg.output

    token = (
        os.environ.get("GCUBE_ACCESS_TOKEN")
        or cfg.auth.access_token
        or None
    )

    # GCUBE_TEAM: numeric team ID. Empty or "0" means unset (personal/unified).
    # Validated eagerly here — unlike config-persisted state, a bad env var is
    # cleared by `unset GCUBE_TEAM` or leaving the shell, so failing fast cannot
    # strand the user.
    eff_team_id = 0
    team_env = os.environ.get("GCUBE_TEAM", "").strip()
    if team_env and team_env != "0":
        if not team_env.isdigit():
            click.echo(
                f"Error: GCUBE_TEAM must be a numeric team ID, got: {team_env}",
                err=True,
            )
            click.echo("  Run 'gcube team list' to find the ID.", err=True)
            sys.exit(1)
        eff_team_id = int(team_env)

    ctx.obj = GcubeContext(
        platform_url=eff_url,
        output=eff_output,  # type: ignore[arg-type]
        debug=debug,
        token=token,
        team_id=eff_team_id,
    )

    # Best-effort PyPI update notice, printed after the command finishes.
    ctx.call_on_close(lambda: check_for_update(__version__))


cli.add_command(auth)
cli.add_command(config)
cli.add_command(completion)
cli.add_command(workload)
cli.add_command(gpu)
cli.add_command(storage)
cli.add_command(resource)
cli.add_command(point)
cli.add_command(credential)
cli.add_command(team)
cli.add_command(skill)

# Command aliases
cli.add_alias("wl", "workload")
cli.add_alias("cred", "credential")
# Legacy name kept for backward compatibility (renamed configure -> config).
cli.add_alias("configure", "config", hidden=True, deprecated=True)


def main() -> None:
    cli()
