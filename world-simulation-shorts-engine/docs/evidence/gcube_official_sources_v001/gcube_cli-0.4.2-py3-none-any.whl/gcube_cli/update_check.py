"""PyPI-based update notifier for gcube CLI.

On most invocations this is a no-op: the latest-version lookup runs against
PyPI at most once per day and the result is cached in ~/.gcube/update_check.json.
Any failure (no network, timeout, malformed response) is swallowed so the
notifier never blocks or breaks a command. The notice is printed to stderr so
machine-readable output (-o json / -o yaml) stays clean.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

import click

from gcube_cli.config import Config

PACKAGE_NAME = "gcube-cli"
PYPI_URL = f"https://pypi.org/pypi/{PACKAGE_NAME}/json"
CACHE_FILE: Path = Config.CONFIG_DIR / "update_check.json"
CHECK_INTERVAL_SECONDS = 24 * 60 * 60  # once per day
HTTP_TIMEOUT_SECONDS = 1.5

# Set GCUBE_NO_UPDATE_CHECK=1 to disable entirely (CI, scripts, air-gapped use).
DISABLE_ENV = "GCUBE_NO_UPDATE_CHECK"


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a dotted release string into a comparable tuple.

    Only the numeric release segment is considered (e.g. "1.2.3a1" -> (1, 2, 3)),
    which is enough to decide "is PyPI ahead of what's installed".
    """
    parts: list[int] = []
    for chunk in v.split("."):
        num = ""
        for ch in chunk:
            if ch.isdigit():
                num += ch
            else:
                break
        if num:
            parts.append(int(num))
        else:
            break
    return tuple(parts) or (0,)


def _read_cache() -> dict[str, object] | None:
    try:
        with open(CACHE_FILE, encoding="utf-8") as fh:
            return json.load(fh)  # type: ignore[no-any-return]
    except (OSError, ValueError):
        return None


def _write_cache(latest: str, checked_at: float) -> None:
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(CACHE_FILE, "w", encoding="utf-8") as fh:
            json.dump({"latest": latest, "checked_at": checked_at}, fh)
    except OSError:
        pass


def _fetch_latest_from_pypi() -> str | None:
    """Query PyPI for the latest released version. Returns None on any failure."""
    try:
        import httpx

        resp = httpx.get(PYPI_URL, timeout=HTTP_TIMEOUT_SECONDS)
        resp.raise_for_status()
        data = resp.json()
        version = data.get("info", {}).get("version")
        return str(version) if version else None
    except Exception:
        return None


def _resolve_latest(now: float) -> str | None:
    """Return the latest version, using the daily cache when it is still fresh."""
    cache = _read_cache()
    if cache:
        checked_at = cache.get("checked_at")
        if isinstance(checked_at, (int, float)) and now - checked_at < CHECK_INTERVAL_SECONDS:
            latest = cache.get("latest")
            return str(latest) if latest else None

    latest = _fetch_latest_from_pypi()
    if latest:
        _write_cache(latest, now)
    return latest


def check_for_update(current_version: str) -> None:
    """Print an upgrade notice to stderr if a newer version exists on PyPI.

    Best-effort and silent on any error. Skipped when:
    - GCUBE_NO_UPDATE_CHECK is set
    - stderr is not a TTY (piped/redirected) — avoids noise in scripts
    - the installed version is a local dev build
    """
    if os.environ.get(DISABLE_ENV):
        return
    if not sys.stderr.isatty():
        return
    if "dev" in current_version:
        return

    now = time.time()
    latest = _resolve_latest(now)
    if not latest:
        return

    if _parse_version(latest) > _parse_version(current_version):
        click.echo(
            click.style(
                f"\n⚠ gcube {latest} is available (you have {current_version}).",
                fg="yellow",
            ),
            err=True,
        )
        click.echo(
            click.style(f"  Upgrade: pip install -U {PACKAGE_NAME}", fg="yellow"),
            err=True,
        )
