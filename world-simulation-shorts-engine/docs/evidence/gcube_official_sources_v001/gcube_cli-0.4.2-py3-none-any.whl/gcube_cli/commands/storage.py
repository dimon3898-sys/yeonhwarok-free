"""Storage subcommands for gcube CLI."""

from __future__ import annotations

import sys

import click

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import APIError, AuthError, decode_email_from_jwt, make_client_from_ctx
from gcube_cli.api.storage import StorageAPI






@click.group("storage", cls=OrderedGroup)
def storage() -> None:
    """Manage personal storage"""


@storage.command("list")
@click.pass_context
def storage_list(ctx: click.Context) -> None:
    """List personal storages"""
    try:
        gcube_ctx = ctx.obj
        client = make_client_from_ctx(ctx)
        owner = decode_email_from_jwt(gcube_ctx.token or "") or ""
        if not owner:
            click.echo(
                "Error: cannot determine user email from token. Please re-authenticate.",
                err=True,
            )
            sys.exit(3)
        api = StorageAPI(client)
        storages = api.list(owner=owner)

        output = gcube_ctx.output
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json([
                {
                    "ser": s.ser,
                    "description": s.description,
                    "type": s.storage_type,
                    "capacity": s.capacity,
                    "accessMode": s.access_mode,
                    "bucket": s.bucket,
                    "mountKey": s.mount_key,
                }
                for s in storages
            ])
        elif output == "yaml":
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml([
                {
                    "ser": s.ser,
                    "description": s.description,
                    "type": s.storage_type,
                    "capacity": s.capacity,
                    "accessMode": s.access_mode,
                    "bucket": s.bucket,
                    "mountKey": s.mount_key,
                }
                for s in storages
            ])
        else:
            if not storages:
                click.echo("No storages found.")
                return
            from gcube_cli.output.table import print_table

            headers = ["MOUNT KEY", "DESCRIPTION", "TYPE", "CAPACITY", "ACCESS MODE"]
            rows = [
                [s.mount_key, s.description, s.storage_type, s.capacity, s.access_mode]
                for s in storages
            ]
            print_table(headers, rows)

    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)
