"""AI agent skill management subcommands."""

from __future__ import annotations

import sys
from importlib import resources
from pathlib import Path

import click

from gcube_cli._group import OrderedGroup

_SKILL_FILE = "gcube_skill.md"
_TOOL_NAME = "gcube"

_TARGETS: dict[str, str] = {
    "claude-code": ".claude/skills",
    "cross-client": ".agents/skills",
}
_DEFAULT_TARGET = "cross-client"


def _load_skill() -> str:
    """Load the bundled skill markdown file."""
    ref = resources.files("gcube_cli.skills").joinpath(_SKILL_FILE)
    return ref.read_text(encoding="utf-8")


def _display_path(p: Path) -> str:
    """Show path with ~ shorthand for home directory."""
    try:
        return "~/" + p.relative_to(Path.home()).as_posix()
    except ValueError:
        return str(p)


def _write_skill(dest: Path, content: str, yes: bool, display_dir: Path) -> None:
    """Write skill file with up-to-date check."""
    label = f"{_TOOL_NAME}/SKILL.md"
    pretty = _display_path(display_dir)

    if dest.exists():
        if dest.read_text(encoding="utf-8") == content:
            click.echo(f"  {label} ... up to date")
            click.echo(f"✓ gcube skill in {pretty} is already up to date")
            return
        if not yes:
            if not click.confirm(f"{dest} already exists. Overwrite?"):
                click.echo("Skipped.")
                return

    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(content, encoding="utf-8")
    click.echo(f"  {label} ... done")
    click.echo(f"✓ Installed gcube skill to {pretty}")
    click.echo("")
    click.echo("The skill is now available in your coding agent.")
    click.echo('Try: "Deploy a GPU workload on GCube"')


@click.group("skill", cls=OrderedGroup)
def skill() -> None:
    """Manage AI agent skill files"""


@skill.command("show")
def skill_show() -> None:
    """Print the gcube skill file to stdout"""
    click.get_binary_stream("stdout").write(_load_skill().encode("utf-8"))


@skill.command("install")
@click.option(
    "--target",
    "-t",
    type=click.Choice(sorted(_TARGETS.keys())),
    default=None,
    help="Target location (claude-code, cross-client)",
)
@click.option(
    "--dir",
    "-d",
    "directory",
    type=click.Path(file_okay=False),
    default=None,
    help="Custom target directory (overrides target default)",
)
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    default=False,
    help="Overwrite without confirmation",
)
def skill_install(target: str | None, directory: str | None, yes: bool) -> None:
    """Install the gcube skill file for an AI coding agent"""
    if target is not None and directory is not None:
        click.echo("Error: --target and --dir are mutually exclusive.", err=True)
        sys.exit(1)

    content = _load_skill()

    if directory is not None:
        base_dir = Path(directory)
    else:
        chosen = target or _DEFAULT_TARGET
        base_dir = Path.home() / _TARGETS[chosen]

    dest = base_dir / _TOOL_NAME / "SKILL.md"
    _write_skill(dest, content, yes, base_dir)
