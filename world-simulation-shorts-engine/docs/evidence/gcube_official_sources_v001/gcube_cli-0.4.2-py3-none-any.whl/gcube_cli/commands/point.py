"""Point status and spending subcommands for gcube CLI (PBI-013)."""

from __future__ import annotations

import base64
import json
import sys

import click

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import APIError, AuthError, make_client_from_ctx
from gcube_cli.api.point import (
    DailySpend,
    PointAPI,
    PointSpendSummary,
    PointStatus,
    _current_month_range,
    _filter_spend_summary_json,
    _filter_spending_json,
    _filter_status_json,
    _month_range,
)


def _get_owner(token: str) -> str:
    try:
        parts = token.split(".")
        if len(parts) == 3:
            padded = parts[1] + "=="
            decoded = json.loads(base64.urlsafe_b64decode(padded).decode("utf-8"))
            return str(decoded.get("email", decoded.get("sub", "")))
    except Exception:
        pass
    return ""


def _fmt_number(n: int | float) -> str:
    return f"{n:,.0f}"


def _fmt_network(rx: float, tx: float) -> str:
    kb = (rx + tx) / 8  # netRx/netTx 단위: Kbps → KB (웹콘솔 toBpsToByte 동일)
    mb = kb / 1024
    gb = mb / 1024
    if mb > 1024.0:
        return f"{gb:.2f}GB"
    if kb > 1024.0:
        return f"{mb:.2f}MB"
    return f"{kb:.2f}KB"


@click.group("point", cls=OrderedGroup)
def point() -> None:
    """View point balance and spending"""


@point.command("status")
@click.pass_context
def point_status(ctx: click.Context) -> None:
    """Show point balance and spending summary"""
    try:
        gcube_ctx = ctx.obj
        client = make_client_from_ctx(ctx)
        owner = _get_owner(gcube_ctx.token or "")
        api = PointAPI(client)

        ps, ps_raw = api.status(owner=owner)
        summary, summary_raw = api.spend_summary(owner=owner)

        output = gcube_ctx.output
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json({
                "status": _filter_status_json(ps_raw),
                "spendSummary": _filter_spend_summary_json(summary_raw),
            })
        elif output == "yaml":
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml({
                "status": _filter_status_json(ps_raw),
                "spendSummary": _filter_spend_summary_json(summary_raw),
            })
        else:
            _print_status_table(ps, summary)

    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)


def _print_status_table(ps: PointStatus, summary: PointSpendSummary) -> None:
    click.echo(f"Available Point: {_fmt_number(ps.available_point):>12} P")
    click.echo(f"Charged Point:   {_fmt_number(ps.charge_point):>12} P")
    click.echo(f"Spent Point:     {_fmt_number(ps.spend_point):>12} P")
    click.echo(f"Network Point:   {_fmt_number(ps.net_point):>12} P")
    click.echo("")
    click.echo("Spending Summary:")
    click.echo(f"  Total:        {_fmt_number(summary.total_spend):>12} P")
    click.echo(f"  Prev Month:   {_fmt_number(summary.prev_month_spend):>12} P")
    click.echo(f"  This Month:   {_fmt_number(summary.this_month_spend):>12} P")
    if ps.is_blocked:
        click.echo("\n⚠ WARNING: Workload blocked due to insufficient points", err=False)
    if ps.is_alarm:
        click.echo("⚠ Low balance alert is active. Please charge points.", err=False)


@point.command("spending")
@click.option("--month", default=None, help="YYYY-MM (default: current month)")
@click.option("--workload", default=None, type=int, help="Workload SER filter")
@click.pass_context
def point_spending(
    ctx: click.Context,
    month: str | None,
    workload: int | None,
) -> None:
    """Show daily point spending history"""
    try:
        gcube_ctx = ctx.obj
        client = make_client_from_ctx(ctx)
        owner = _get_owner(gcube_ctx.token or "")
        api = PointAPI(client)

        if month:
            start_time, end_time = _month_range(month)
        else:
            start_time, end_time = _current_month_range()

        spends, raw_items = api.daily_spends(
            owner=owner,
            workload=workload,
            start_time=start_time,
            end_time=end_time,
        )

        output = gcube_ctx.output
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json(_filter_spending_json(raw_items))
        elif output == "yaml":
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml(_filter_spending_json(raw_items))
        else:
            _print_spending_table(spends)

    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)


def _print_spending_table(spends: list[DailySpend]) -> None:
    from gcube_cli.output.table import print_table

    headers = ["DATE", "POINT", "KRW", "BASE", "USAGE", "GPU%", "NETWORK"]
    rows = [
        [
            s.date,
            f"{s.gpu_point:,.2f}P",
            f"₩{_fmt_number(s.krw_gpu_amount)}",
            f"₩{_fmt_number(s.krw_gpu_unit_amount)}",
            f"₩{_fmt_number(s.krw_gpu_usage_amount)}",
            f"{s.gpu_usage:.2f}%",
            _fmt_network(s.net_rx, s.net_tx),
        ]
        for s in spends
    ]
    print_table(headers, rows)
