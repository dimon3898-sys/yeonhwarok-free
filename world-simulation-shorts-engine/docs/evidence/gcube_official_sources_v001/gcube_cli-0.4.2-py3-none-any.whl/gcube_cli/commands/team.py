"""Team subcommands for gcube CLI (PBI-023).

Read-only team commands plus creation.  There is deliberately no ``team switch``
— team context is set per-invocation via ``--team`` or ``GCUBE_TEAM`` so it is
always visible at the call site (see PBI-023 §10).
"""

from __future__ import annotations

import sys
from typing import Any

import click

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import handle_api_errors, make_client_from_ctx
from gcube_cli.api.team import Team, TeamAPI, TeamMember, TeamPointStatus

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_NAME_MIN = 2
_NAME_MAX = 50
_DESCRIPTION_MAX = 200


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fmt_number(n: float) -> str:
    return f"{n:,.0f}"


def _dash(value: str) -> str:
    """Render an empty string as '-' for table output."""
    return value or "-"


def _team_public_dict(team: Team, my_role: str, member_count: int) -> dict[str, Any]:
    """Flat JSON shape for a team.

    Deliberately flat: the API nests as ``teams[].team.name``, which is awkward
    to script against.  Mirrors the ``to_public_dict()`` convention used by
    ``api/workload.py``.
    """
    return {
        "teamId": team.team_id,
        "name": team.name,
        "description": team.description or None,
        "ownerEmail": team.owner_email,
        "namespace": team.namespace,
        "status": team.status,
        "myRole": my_role,
        "memberCount": member_count,
    }


def _member_public_dict(m: TeamMember) -> dict[str, Any]:
    """Flat JSON shape for a member.

    ``status`` / ``joinedAt`` are omitted entirely when the server did not send
    them (the live API currently returns only email/name/role) rather than being
    padded with empty strings — an absent key is honest, "" is not.
    """
    out: dict[str, Any] = {
        "email": m.email,
        "name": m.name or None,
        "role": m.role,
    }
    if m.status:
        out["status"] = m.status
    if m.joined_at:
        out["joinedAt"] = m.joined_at
    return out


def _point_public_dict(p: TeamPointStatus) -> dict[str, Any]:
    return {
        "charged": p.charged_point,
        "used": p.used_point,
        "network": p.network_point,
        "remaining": p.remaining_point,
        "workloadCount": p.workload_count,
    }


def _find_point(api: TeamAPI, team_id: int) -> TeamPointStatus | None:
    """Fetch team points and pick this team's entry.

    Non-fatal: the point endpoint is a secondary lookup, so any failure leaves
    ``team show`` succeeding without the Point section.  Mirrors how
    ``workload describe`` treats its schedule fetch.

    ``SystemExit`` is caught alongside ``Exception`` because ``Client._request``
    calls ``sys.exit(4)`` on network/timeout errors — without it a flaky
    connection on this secondary call would kill the whole command.  Same
    reasoning as ``Client.get_quiet``.
    """
    try:
        for p in api.get_points():
            if p.team_id == team_id:
                return p
    except (Exception, SystemExit):
        return None
    return None


# ---------------------------------------------------------------------------
# Command group
# ---------------------------------------------------------------------------


@click.group("team", cls=OrderedGroup)
def team() -> None:
    """Manage teams"""


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@team.command("list")
@click.pass_context
@handle_api_errors
def team_list(ctx: click.Context) -> None:
    """List my teams

    This is the only way to discover team IDs. Both --team and GCUBE_TEAM take
    numeric IDs, because team names are not unique.
    """
    # Help text stays ASCII-only on purpose: Click writes docstrings straight to
    # stdout, and a legacy Windows console (cp949/cp437) raises
    # UnicodeEncodeError on characters it cannot encode, crashing `--help`.
    api = TeamAPI(make_client_from_ctx(ctx))
    my_teams = api.list_my_teams()

    output = ctx.obj.output
    if output in ("json", "yaml"):
        rows = [
            _team_public_dict(mt.team, mt.my_role, mt.member_count)
            for mt in my_teams
        ]
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json(rows)
        else:
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml(rows)
        return

    if not my_teams:
        click.echo("No teams found.")
        return

    from gcube_cli.output.table import print_table

    headers = ["ID", "NAME", "ROLE", "MEMBERS", "STATUS", "OWNER"]
    table_rows = [
        [
            str(mt.team.team_id),
            mt.team.name,
            mt.my_role,
            str(mt.member_count),
            mt.team.status,
            mt.team.owner_email,
        ]
        for mt in my_teams
    ]
    print_table(headers, table_rows)


# ---------------------------------------------------------------------------
# show
# ---------------------------------------------------------------------------


@team.command("show")
@click.argument("team_id", type=int)
@click.pass_context
@handle_api_errors
def team_show(ctx: click.Context, team_id: int) -> None:
    """Show team details, members, and points"""
    api = TeamAPI(make_client_from_ctx(ctx))
    team_obj, my_role, members = api.get_detail(team_id)
    point = _find_point(api, team_id)

    output = ctx.obj.output
    if output in ("json", "yaml"):
        data = _team_public_dict(team_obj, my_role, len(members))
        data["createdAt"] = team_obj.created_at or None
        data["members"] = [_member_public_dict(m) for m in members]
        data["point"] = _point_public_dict(point) if point else None
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json(data)
        else:
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml(data)
        return

    _print_show(team_obj, my_role, members, point)


def _print_show(
    team_obj: Team,
    my_role: str,
    members: list[TeamMember],
    point: TeamPointStatus | None,
) -> None:
    """kubectl-describe style plain text, matching ``workload describe``."""
    click.echo(f"Team: {team_obj.name} (ID: {team_obj.team_id})")
    click.echo(f"  Description:  {_dash(team_obj.description)}")
    click.echo(f"  Owner:        {team_obj.owner_email}")
    click.echo(f"  Namespace:    {_dash(team_obj.namespace)}")
    click.echo(f"  Status:       {team_obj.status}")
    click.echo(f"  Created:      {_dash(team_obj.created_at)}")
    click.echo(f"  My Role:      {my_role}")

    click.echo()
    click.echo(f"Members ({len(members)}):")
    if members:
        from gcube_cli.output.table import print_table

        # STATUS / JOINED are conditional: the live API omits them, so showing
        # empty columns would just be noise.  They appear only if the server
        # actually sent a value for at least one member.
        show_status = any(m.status for m in members)
        show_joined = any(m.joined_at for m in members)

        headers = ["EMAIL", "NAME", "ROLE"]
        if show_status:
            headers.append("STATUS")
        if show_joined:
            headers.append("JOINED")

        rows: list[list[str]] = []
        for m in members:
            row = [m.email, _dash(m.name), m.role]
            if show_status:
                row.append(_dash(m.status))
            if show_joined:
                row.append(_dash(m.joined_at))
            rows.append(row)
        print_table(headers, rows)

    if point is not None:
        click.echo()
        click.echo("Point:")
        click.echo(f"  Charged:    {_fmt_number(point.charged_point)}")
        click.echo(f"  Used:       {_fmt_number(point.used_point)}")
        click.echo(f"  Network:    {_fmt_number(point.network_point)}")
        click.echo(f"  Remaining:  {_fmt_number(point.remaining_point)}")
        click.echo(f"  Workloads:  {point.workload_count}")


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@team.command("create")
@click.option("--name", required=True, help=f"Team name ({_NAME_MIN}-{_NAME_MAX} chars)")
@click.option("--description", default=None, help=f"Team description (max {_DESCRIPTION_MAX})")
@click.pass_context
@handle_api_errors
def team_create(ctx: click.Context, name: str, description: str | None) -> None:
    """Create a new team

    You become the owner of the new team.
    """
    # Client-side validation mirrors the web console form so an obviously bad
    # name fails locally instead of costing a round trip.
    trimmed = name.strip()
    if not (_NAME_MIN <= len(trimmed) <= _NAME_MAX):
        click.echo(
            f"Error: team name must be {_NAME_MIN}-{_NAME_MAX} characters "
            f"after trimming (got {len(trimmed)}).",
            err=True,
        )
        sys.exit(1)

    desc = (description or "").strip() or None
    if desc is not None and len(desc) > _DESCRIPTION_MAX:
        click.echo(
            f"Error: description must be at most {_DESCRIPTION_MAX} characters "
            f"(got {len(desc)}).",
            err=True,
        )
        sys.exit(1)

    api = TeamAPI(make_client_from_ctx(ctx))
    created = api.create(trimmed, desc)

    output = ctx.obj.output
    if output in ("json", "yaml"):
        data = {
            "teamId": created.team_id,
            "name": created.name,
            "ownerEmail": created.owner_email,
            "status": created.status,
        }
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json(data)
        else:
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml(data)
    else:
        click.echo(f"Team created: {created.name} (ID: {created.team_id})")
        click.echo(f"  Owner: {created.owner_email}")
        click.echo(f"  Status: {created.status}")

    # There is no `team switch`, so spell out how to use the new team.
    # stderr keeps machine-readable stdout clean.
    click.echo(
        f"Use it with: gcube workload register -f x.yaml --team {created.team_id}",
        err=True,
    )
