"""Shell completion subcommands for gcube CLI."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import click
from click.shell_completion import get_completion_class

from gcube_cli._group import OrderedGroup

_SHELLS = ("bash", "zsh", "fish")

_PROG_NAME = "gcube"
_COMPLETE_VAR = f"_{_PROG_NAME.upper()}_COMPLETE"

# Patterns used by Click 8.x completion templates.  If Click changes its
# templates these will silently no-op, but the per-shell tests assert the
# patched marker is present so CI will catch the breakage.
_CR_PATCHES = {
    "bash": (
        f"{_COMPLETE_VAR}=bash_complete $1)",
        f"{_COMPLETE_VAR}=bash_complete $1 | tr -d '\\r')",
    ),
    "zsh": (
        f"{_COMPLETE_VAR}=zsh_complete {_PROG_NAME})" + '}")',
        f"{_COMPLETE_VAR}=zsh_complete {_PROG_NAME} | tr -d '\\r')" + '}")',
    ),
    "fish": (
        f"{_COMPLETE_VAR}=fish_complete"
        f" COMP_WORDS=(commandline -cp)"
        f" COMP_CWORD=(commandline -t) {_PROG_NAME});",
        f"{_COMPLETE_VAR}=fish_complete"
        f" COMP_WORDS=(commandline -cp)"
        f" COMP_CWORD=(commandline -t) {_PROG_NAME} | tr -d '\\r');",
    ),
}


def _get_completion_script(shell: str) -> str:
    """Generate completion script using Click's shell_completion API."""
    from gcube_cli.cli import cli as cli_group

    comp_cls = get_completion_class(shell)
    if comp_cls is None:
        return ""
    comp = comp_cls(cli_group, {}, _PROG_NAME, _COMPLETE_VAR)
    script = comp.source()

    # On Windows, Python outputs \r\n which leaves ^M in completion values.
    # Patch the script to pipe through tr -d '\r'.
    if shell in _CR_PATCHES:
        old, new = _CR_PATCHES[shell]
        script = script.replace(old, new)
    return script


# ---------------------------------------------------------------------------
# completion group
# ---------------------------------------------------------------------------


@click.group("completion", cls=OrderedGroup)
def completion() -> None:
    """Generate shell completion scripts"""


@completion.command("bash")
def completion_bash() -> None:
    """Print bash completion script"""
    click.echo(_get_completion_script("bash"))


@completion.command("zsh")
def completion_zsh() -> None:
    """Print zsh completion script"""
    click.echo(_get_completion_script("zsh"))


@completion.command("fish")
def completion_fish() -> None:
    """Print fish completion script"""
    click.echo(_get_completion_script("fish"))


# ---------------------------------------------------------------------------
# install
# ---------------------------------------------------------------------------

def _detect_shell() -> str | None:
    """Auto-detect the current shell."""
    shell_path = os.environ.get("SHELL", "")
    name = Path(shell_path).name
    if name in _SHELLS:
        return name
    return None


_BASHRC_SOURCE = (
    'for f in ~/.bash_completion.d/*; do [ -f "$f" ] && . "$f"; done'
)


def _install_bash(script: str) -> Path:
    """Install bash completion script."""
    comp_dir = Path.home() / ".bash_completion.d"
    comp_dir.mkdir(parents=True, exist_ok=True)
    target = comp_dir / _PROG_NAME
    target.write_text(script, encoding="utf-8")

    # Ensure ~/.bashrc sources the directory
    bashrc = Path.home() / ".bashrc"
    if bashrc.exists():
        content = bashrc.read_text(encoding="utf-8")
        if ".bash_completion.d" not in content:
            with open(bashrc, "a", encoding="utf-8") as fh:
                fh.write(
                    f"\n# {_PROG_NAME} shell completion\n"
                    f"{_BASHRC_SOURCE}\n"
                )
    else:
        bashrc.write_text(
            f"# {_PROG_NAME} shell completion\n{_BASHRC_SOURCE}\n",
            encoding="utf-8",
        )
    return target


def _install_zsh(script: str) -> Path:
    """Install zsh completion script."""
    comp_dir = Path.home() / ".zfunc"
    comp_dir.mkdir(parents=True, exist_ok=True)
    target = comp_dir / f"_{_PROG_NAME}"
    target.write_text(script, encoding="utf-8")

    # Ensure ~/.zshrc has fpath and compinit
    zshrc = Path.home() / ".zshrc"
    zsh_block = (
        f"\n# {_PROG_NAME} shell completion\n"
        "fpath=(~/.zfunc $fpath)\n"
        "autoload -Uz compinit && compinit\n"
    )
    if zshrc.exists():
        content = zshrc.read_text(encoding="utf-8")
        if ".zfunc" not in content:
            with open(zshrc, "a", encoding="utf-8") as fh:
                fh.write(zsh_block)
    else:
        zshrc.write_text(zsh_block.lstrip("\n"), encoding="utf-8")
    return target


def _install_fish(script: str) -> Path:
    """Install fish completion script."""
    comp_dir = Path.home() / ".config" / "fish" / "completions"
    comp_dir.mkdir(parents=True, exist_ok=True)
    target = comp_dir / f"{_PROG_NAME}.fish"
    target.write_text(script, encoding="utf-8")
    return target


_INSTALLERS = {
    "bash": _install_bash,
    "zsh": _install_zsh,
    "fish": _install_fish,
}


@completion.command("install")
@click.option(
    "--shell",
    type=click.Choice(_SHELLS),
    default=None,
    help="Shell to install for (auto-detected if omitted)",
)
def completion_install(shell: str | None) -> None:
    """Auto-detect shell and install completion script"""
    if shell is None:
        shell = _detect_shell()
        if shell is None:
            click.echo(
                "Could not detect shell. Use --shell to specify one.",
                err=True,
            )
            sys.exit(1)

    script = _get_completion_script(shell)
    if not script.strip():
        click.echo(f"Failed to generate {shell} completion script.", err=True)
        sys.exit(1)

    installer = _INSTALLERS[shell]
    target = installer(script)
    click.echo(f"Installed {shell} completion to {target}")
    click.echo("Restart your shell or source the file to activate.")
