"""Config subcommands for gcube CLI."""

from __future__ import annotations

import os
import sys

import click

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import decode_email_from_jwt
from gcube_cli.config.config import Config

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mask_token(token: str) -> str:
    """Return first 8 chars + '...' or '(not set)' if empty."""
    if not token:
        return "(not set)"
    return token[:8] + "..."


# ---------------------------------------------------------------------------
# Command group
# ---------------------------------------------------------------------------


@click.group("config", cls=OrderedGroup, invoke_without_command=True)
@click.pass_context
def config(ctx: click.Context) -> None:
    """Manage CLI configuration"""
    if ctx.invoked_subcommand is None:
        # Interactive mode — prompt with current values as defaults
        cfg = Config.load()

        platform_url = click.prompt("Platform URL", default=cfg.platform_url)
        ws_url = click.prompt("WebSocket URL", default=cfg.ws_url)

        token_hint = _mask_token(cfg.auth.access_token)
        new_token = click.prompt(
            f"Access Token [{token_hint}]",
            default=cfg.auth.access_token,
            show_default=False,
        )

        # Auto-extract email from JWT; fall back to current value
        auto_email = decode_email_from_jwt(new_token) if new_token else None
        email_default = auto_email or cfg.auth.user_email
        new_email = click.prompt("Email", default=email_default or "")

        output = click.prompt(
            "Output format",
            default=cfg.output,
            type=click.Choice(["table", "json", "yaml"]),
        )

        cfg.platform_url = platform_url
        cfg.ws_url = ws_url
        cfg.auth.access_token = new_token
        cfg.auth.user_email = new_email
        cfg.output = output
        Config.save(cfg)
        click.echo("Configuration saved.")


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


@config.command("set")
@click.option("--token", default=None, help="API access token")
@click.option("--platform-url", default=None, help="Platform base URL")
@click.option("--ws-url", default=None, help="WebSocket base URL for log streaming")
@click.option("--email", default=None, help="User email for API calls")
@click.option(
    "--output",
    type=click.Choice(["table", "json", "yaml"]),
    default=None,
    help="Default output format",
)
@click.pass_context
def configure_set(
    ctx: click.Context,
    token: str | None,
    platform_url: str | None,
    ws_url: str | None,
    email: str | None,
    output: str | None,
) -> None:
    """Set a configuration value"""
    if all(v is None for v in (token, platform_url, ws_url, email, output)):
        click.echo("Nothing to set. Use --token, --platform-url, --ws-url, --email, or --output.")
        return

    cfg = Config.load()
    if token is not None:
        cfg.auth.access_token = token
        # Auto-extract email from JWT if not explicitly provided
        if email is None:
            extracted = decode_email_from_jwt(token)
            if extracted:
                cfg.auth.user_email = extracted
        click.echo("Token saved.")
    if platform_url is not None:
        cfg.platform_url = platform_url
        click.echo("Platform URL saved.")
    if ws_url is not None:
        cfg.ws_url = ws_url
        click.echo("WebSocket URL saved.")
    if email is not None:
        cfg.auth.user_email = email
        click.echo("Email saved.")
    if output is not None:
        cfg.output = output
        click.echo("Output format saved.")
    Config.save(cfg)


@config.command("get")
@click.argument("key")
@click.pass_context
def configure_get(ctx: click.Context, key: str) -> None:
    """Get a configuration value"""
    valid_keys = ("token", "platform-url", "ws-url", "email", "output")
    if key not in valid_keys:
        click.echo(
            f"Error: Unknown key: {key}. Valid keys: {', '.join(valid_keys)}",
            err=True,
        )
        sys.exit(1)

    cfg = Config.load()
    if key == "token":
        click.echo(_mask_token(cfg.auth.access_token))
    elif key == "platform-url":
        click.echo(cfg.platform_url)
    elif key == "ws-url":
        click.echo(cfg.ws_url)
    elif key == "email":
        click.echo(cfg.auth.user_email or "(not set)")
    elif key == "output":
        click.echo(cfg.output)


@config.command("status")
@click.pass_context
def configure_status(ctx: click.Context) -> None:
    """Show current configuration"""
    cfg = Config.load()
    raw = Config.load_raw()

    def _src(env_var: str | None, yaml_key: str) -> str:
        """Determine source: env > config > default."""
        if env_var and os.environ.get(env_var):
            return f"env: {env_var}"
        if yaml_key in raw:
            return "config"
        return "default"

    # Effective values (same priority as cli())
    eff_platform = os.environ.get("GCUBE_PLATFORM_URL") or cfg.platform_url
    eff_ws = cfg.ws_url
    eff_token = os.environ.get("GCUBE_ACCESS_TOKEN") or cfg.auth.access_token
    eff_output = os.environ.get("GCUBE_OUTPUT") or cfg.output

    # Auth summary — details are in `gcube auth status`
    auth_status = "logged in" if eff_token else "not logged in"

    click.echo(f"Auth Status  : {auth_status}")
    click.echo(f"Platform URL : {eff_platform}  ({_src('GCUBE_PLATFORM_URL', 'platform_url')})")
    click.echo(f"WebSocket URL: {eff_ws}  ({_src(None, 'ws_url')})")
    click.echo(f"Output Format: {eff_output}  ({_src('GCUBE_OUTPUT', 'output')})")


# Help display order
config.commands = {k: config.commands[k] for k in ["status", "set", "get"]}  # type: ignore[assignment]
