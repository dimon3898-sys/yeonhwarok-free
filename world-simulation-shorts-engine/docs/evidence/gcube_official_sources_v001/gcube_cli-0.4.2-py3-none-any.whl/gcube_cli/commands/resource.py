"""Resource monitoring subcommands for gcube CLI (PBI-011)."""

from __future__ import annotations

import dataclasses
import sys

import click

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import APIError, AuthError, make_client_from_ctx
from gcube_cli.api.resource import ResourceAPI, ResourceUsage





_HEADERS = [
    "POD",
    "TIME",
    "GPU(%)",
    "VRAM(%)",
    "CPU(%)",
    "MEM(%)",
    "DISK(%)",
    "NET_RX(kbps)",
    "NET_TX(kbps)",
]


def _usage_row(pod: str, u: ResourceUsage) -> list[str]:
    return [
        pod,
        u.time_interval or "",
        str(u.gpu_usage),
        str(u.vram_usage),
        str(u.cpu_usage),
        str(u.mem_usage),
        str(u.disk_usage),
        str(u.net_rx),
        str(u.net_tx),
    ]


def _output_workload(ctx: click.Context, result: dict[str, list[ResourceUsage]]) -> None:
    output = ctx.obj.output
    if output == "json":
        from gcube_cli.output.json_out import print_json
        print_json(
            {pod: [dataclasses.asdict(u) for u in usages] for pod, usages in result.items()}
        )
    elif output == "yaml":
        from gcube_cli.output.yaml_out import print_yaml
        print_yaml(
            {pod: [dataclasses.asdict(u) for u in usages] for pod, usages in result.items()}
        )
    else:
        from gcube_cli.output.table import print_table
        rows = [
            _usage_row(pod, u)
            for pod, usages in result.items()
            for u in usages
        ]
        print_table(_HEADERS, rows)


@click.group("resource", cls=OrderedGroup)
def resource() -> None:
    """Monitor resource usage"""


@resource.command("workload")
@click.argument("ser")
@click.pass_context
def resource_workload(ctx: click.Context, ser: str) -> None:
    """Show resource usage of a workload"""
    try:
        client = make_client_from_ctx(ctx)
        api = ResourceAPI(client)
        result = api.workload(ser)
        _output_workload(ctx, result)
    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)
