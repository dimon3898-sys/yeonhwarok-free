"""Credential management subcommands for gcube CLI (PBI-012)."""

from __future__ import annotations

import base64
import json
import sys

import click

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import APIError, AuthError, make_client_from_ctx
from gcube_cli.api.credential import Credential, CredentialAPI

REPO_TYPES = ["docker", "github", "harbor", "aws", "huggingface", "quay"]
_SECRET_MASK = "************"


def _get_owner(token: str) -> str:
    """Try to extract owner email from JWT token payload (best-effort)."""
    try:
        parts = token.split(".")
        if len(parts) == 3:
            padded = parts[1] + "=="
            decoded = json.loads(base64.urlsafe_b64decode(padded).decode("utf-8"))
            return str(decoded.get("email", decoded.get("sub", "")))
    except Exception:
        pass
    return ""


@click.group("credential", cls=OrderedGroup)
def credential() -> None:
    """Manage registry credentials"""


@credential.command("list")
@click.pass_context
def credential_list(ctx: click.Context) -> None:
    """List saved credentials"""
    try:
        gcube_ctx = ctx.obj
        client = make_client_from_ctx(ctx)
        owner = _get_owner(gcube_ctx.token or "")
        if not owner:
            click.echo("Error: could not extract owner from token. Please re-login.", err=True)
            sys.exit(3)
        api = CredentialAPI(client)
        creds = api.list(owner=owner)

        output = gcube_ctx.output
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json(
                [
                    {"repo": c.cloud, "username": c.acc_key, "secret": _SECRET_MASK}
                    for c in creds
                ]
            )
        elif output == "yaml":
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml(
                [
                    {"repo": c.cloud, "username": c.acc_key, "secret": _SECRET_MASK}
                    for c in creds
                ]
            )
        else:
            if not creds:
                click.echo("No credentials found.")
                return
            from gcube_cli.output.table import print_table

            headers = ["REPO", "USERNAME", "SECRET"]
            rows = [[c.cloud, c.acc_key, _SECRET_MASK] for c in creds]
            print_table(headers, rows)
    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)


@credential.command("create")
@click.option(
    "--repo",
    required=True,
    type=click.Choice(REPO_TYPES),
    help="Registry type",
)
@click.option("--username", required=True, help="Access key / username")
@click.option("--token", "token_value", required=True, help="Secret key / token / password")
@click.option("--region", default=None, help="AWS ECR region (required for aws)")
@click.option("--registry-id", default=None, help="AWS ECR registry ID")
@click.pass_context
def credential_create(
    ctx: click.Context,
    repo: str,
    username: str,
    token_value: str,
    region: str | None,
    registry_id: str | None,
) -> None:
    """Create a new credential"""
    if repo == "aws" and not region:
        raise click.UsageError("--region is required for AWS ECR")
    try:
        gcube_ctx = ctx.obj
        client = make_client_from_ctx(ctx)
        owner = _get_owner(gcube_ctx.token or "")
        if not owner:
            click.echo("Error: could not extract owner from token. Please re-login.", err=True)
            sys.exit(3)
        api = CredentialAPI(client)
        cred = Credential(
            owner=owner,
            category="repo",
            cloud=repo,
            acc_key=username,
            sec_key=token_value,
            region=region,
            registry_id=registry_id,
        )
        api.create(cred)
        click.echo(f"Credential ({repo}) registered.")
    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)


@credential.command("delete")
@click.option(
    "--repo",
    required=True,
    type=click.Choice(REPO_TYPES),
    help="Registry type",
)
@click.confirmation_option(
    prompt="Are you sure you want to delete this credential?",
    help="Confirm the action without prompting",
)
@click.pass_context
def credential_delete(ctx: click.Context, repo: str) -> None:
    """Delete a credential"""
    try:
        client = make_client_from_ctx(ctx)
        api = CredentialAPI(client)
        api.delete(repo)
        click.echo(f"Credential ({repo}) deleted.")
    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)
