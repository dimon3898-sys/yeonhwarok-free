"""Auth commands for gcube CLI.

Implements browser-based PKCE authentication:
  gcube auth login  - opens browser, receives code via localhost callback, exchanges for token
  gcube auth logout - clears local credentials
  gcube auth status - shows current auth state
"""

from __future__ import annotations

import base64
import hashlib
import os
import secrets
import sys
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any
from urllib.parse import parse_qs, urlencode, urlparse

import click
import httpx

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import decode_email_from_jwt, decode_jwt_payload
from gcube_cli.config.config import Config

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DEFAULT_CLIENT_ID = "5a72d168-10c1-4001-a303-7a05b854e387"
_LOGIN_TIMEOUT = 300  # 5 minutes
_VERIFY_TIMEOUT = 30  # seconds


# ---------------------------------------------------------------------------
# PKCE (RFC 7636)
# ---------------------------------------------------------------------------


def _generate_pkce() -> tuple[str, str]:
    """Generate PKCE code_verifier (86 chars) and code_challenge (43 chars)."""
    verifier = base64.urlsafe_b64encode(os.urandom(64)).rstrip(b"=").decode("ascii")
    challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest())
        .rstrip(b"=")
        .decode("ascii")
    )
    return verifier, challenge


def _generate_state() -> str:
    """Generate CSRF-protection state (43 chars)."""
    return secrets.token_urlsafe(32)


# ---------------------------------------------------------------------------
# Console URL resolution
# ---------------------------------------------------------------------------


def _resolve_console_url(platform_url: str) -> str:
    """Resolve console URL. Priority: env > derive from platform_url.

    api.gcube.ai -> console.gcube.ai (auto-derive)
    """
    env = os.environ.get("GCUBE_CONSOLE_URL")
    if env:
        return env
    if "://api." not in platform_url:
        click.echo(
            f"Warning: Cannot derive console URL from '{platform_url}'. "
            "Set GCUBE_CONSOLE_URL environment variable.",
            err=True,
        )
    return platform_url.replace("://api.", "://console.").rstrip("/")


def _resolve_client_id(cfg_client_id: str) -> str:
    """Resolve client_id: env > config > default."""
    return (
        os.environ.get("GCUBE_CLIENT_ID")
        or cfg_client_id
        or _DEFAULT_CLIENT_ID
    )


# ---------------------------------------------------------------------------
# Signin URL builder
# ---------------------------------------------------------------------------


def _build_signin_url(
    console_url: str,
    client_id: str,
    port: int,
    challenge: str,
    state: str,
) -> str:
    params = urlencode({
        "client_id": client_id,
        "redirect_uri": f"http://127.0.0.1:{port}",
        "response_type": "code",
        "code_challenge_method": "S256",
        "code_challenge": challenge,
        "state": state,
    })
    return f"{console_url}/agent/signin?{params}"


# ---------------------------------------------------------------------------
# Verify request
# ---------------------------------------------------------------------------


def _request_verify(
    api_url: str,
    client_id: str,
    code: str,
    code_verifier: str,
) -> dict[str, Any]:
    """POST /agent/signin/verify -> {status, access_token, email}."""
    resp = httpx.post(
        f"{api_url}/agent/signin/verify",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        content=urlencode({
            "client_id": client_id,
            "code": code,
            "code_verifier": code_verifier,
        }),
        timeout=_VERIFY_TIMEOUT,
    )
    if not resp.is_success:
        raise click.ClickException(
            f"Token verification failed (HTTP {resp.status_code}): {resp.text[:200]}"
        )
    data = resp.json()
    if "access_token" not in data:
        raise click.ClickException(
            "Token verification failed: no access_token in response"
        )
    return data


# ---------------------------------------------------------------------------
# Loopback callback server
# ---------------------------------------------------------------------------


class _CallbackResult:
    """Thread-safe container for the callback result."""

    def __init__(self) -> None:
        self.code: str = ""
        self.error: str = ""
        self.received = threading.Event()
        self._response_ready = threading.Event()
        self._response_result: str = "failed"


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures the OAuth callback code."""

    result: _CallbackResult
    expected_state: str
    result_base_url: str

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path != "/":
            self.send_response(404)
            self.end_headers()
            return

        params = parse_qs(parsed.query)
        state = params.get("state", [""])[0]
        error = params.get("error", [""])[0]
        code = params.get("code", [""])[0]

        # State mismatch or error -> immediate redirect to /failed
        if not secrets.compare_digest(state, self.expected_state):
            self.result.error = "state_mismatch"
            self.result.received.set()
            self.send_response(302)
            self.send_header("Location", f"{self.result_base_url}/failed")
            self.end_headers()
            return

        if error:
            self.result.error = error
            self.result.received.set()
            self.send_response(302)
            self.send_header("Location", f"{self.result_base_url}/failed")
            self.end_headers()
            return

        if not code:
            self.result.error = "missing_code"
            self.result.received.set()
            self.send_response(302)
            self.send_header("Location", f"{self.result_base_url}/failed")
            self.end_headers()
            return

        # Valid code: hold the response until verify completes
        self.result.code = code
        self.result.received.set()

        # Wait for verify result (up to VERIFY_TIMEOUT + margin)
        self.result._response_ready.wait(timeout=_VERIFY_TIMEOUT + 5)
        redirect = f"{self.result_base_url}/{self.result._response_result}"
        self.send_response(302)
        self.send_header("Location", redirect)
        self.end_headers()

    def log_message(self, format: str, *args: Any) -> None:
        pass


def _start_callback_server(
    result: _CallbackResult,
    expected_state: str,
    result_base_url: str,
) -> HTTPServer:
    """Start a loopback HTTP server on an ephemeral port."""
    handler = type("Handler", (_CallbackHandler,), {
        "result": result,
        "expected_state": expected_state,
        "result_base_url": result_base_url,
    })
    server = HTTPServer(("127.0.0.1", 0), handler)  # type: ignore[arg-type]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server


# ---------------------------------------------------------------------------
# Browser opener
# ---------------------------------------------------------------------------


def _open_browser(url: str) -> None:
    """Open URL in the default browser."""
    try:
        webbrowser.open(url)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# JWT helpers
# ---------------------------------------------------------------------------


def _token_expiry_display(token: str) -> str:
    """Return human-readable expiry from JWT exp claim."""
    from datetime import datetime, timezone

    payload = decode_jwt_payload(token)
    if payload is None:
        return "unknown"
    exp = payload.get("exp")
    if not exp:
        return "unknown"
    try:
        dt = datetime.fromtimestamp(exp, tz=timezone.utc)
        return dt.strftime("%Y-%m-%d %H:%M UTC")
    except (OSError, ValueError):
        return "unknown"


# ---------------------------------------------------------------------------
# Command group
# ---------------------------------------------------------------------------


@click.group("auth", cls=OrderedGroup)
def auth() -> None:
    """Manage authentication"""


# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------


@auth.command("login")
def auth_login() -> None:
    """Log in via browser"""
    cfg = Config.load()
    platform_url = os.environ.get("GCUBE_PLATFORM_URL") or cfg.platform_url
    console_url = _resolve_console_url(platform_url)
    client_id = _resolve_client_id(cfg.client_id)

    # PKCE + state
    verifier, challenge = _generate_pkce()
    state = _generate_state()

    # Start callback server
    result = _CallbackResult()
    result_base_url = f"{console_url}/agent/signin"
    server = _start_callback_server(result, state, result_base_url)
    port = server.server_address[1]

    signin_url = _build_signin_url(console_url, client_id, port, challenge, state)

    click.echo("Opening browser for login...", err=True)
    click.echo("If the browser doesn't open, visit:", err=True)
    click.echo(f"  {signin_url}", err=True)
    _open_browser(signin_url)

    click.echo("Waiting for browser login...", err=True)
    # Poll in short intervals so Ctrl+C works
    elapsed = 0.0
    while elapsed < _LOGIN_TIMEOUT and not result.received.is_set():
        result.received.wait(timeout=0.5)
        elapsed += 0.5
    if not result.received.is_set():
        server.shutdown()
        click.echo("Login timed out. Please try again.", err=True)
        sys.exit(1)

    # Check for errors (state mismatch, server error, missing code)
    if result.error:
        server.shutdown()
        click.echo(f"Login failed: {result.error}", err=True)
        sys.exit(1)

    # Exchange code for token
    try:
        verify_result = _request_verify(
            platform_url, client_id, result.code, verifier,
        )
        result._response_result = "success"
    except click.ClickException:
        result._response_result = "failed"
        result._response_ready.set()
        server.shutdown()
        raise
    finally:
        result._response_ready.set()

    # Shutdown blocks until the handler thread completes the browser redirect
    server.shutdown()

    # Save credentials
    cfg.auth.access_token = verify_result["access_token"]
    cfg.auth.user_email = verify_result.get("email", "")
    Config.save(cfg)

    click.echo(f"Logged in as {cfg.auth.user_email}")


@auth.command("logout")
def auth_logout() -> None:
    """Log out and clear local credentials"""
    cfg = Config.load()

    if not cfg.auth.access_token:
        click.echo("Not logged in.", err=True)
        return

    cfg.auth.access_token = ""
    cfg.auth.user_email = ""
    Config.save(cfg)

    click.echo("Logged out.")


@auth.command("status")
def auth_status() -> None:
    """Show current authentication status"""
    cfg = Config.load()

    if not cfg.auth.access_token:
        click.echo("Not logged in.")
        click.echo('Run "gcube auth login" to authenticate.')
        return

    email = cfg.auth.user_email or decode_email_from_jwt(cfg.auth.access_token) or ""
    expiry = _token_expiry_display(cfg.auth.access_token)

    click.echo(f"Email:   {email}")
    click.echo(f"Expires: {expiry}")
    click.echo(f"Token:   {cfg.auth.access_token[:20]}...")
