"""GPU subcommands for gcube CLI (PBI-015)."""

from __future__ import annotations

import re
import sys
from typing import Any

import click

from gcube_cli._group import OrderedGroup
from gcube_cli.api.client import APIError, AuthError, make_client_from_ctx
from gcube_cli.api.workload import GpuPricing, WorkloadAPI





def _num_out(v: float) -> int | float:
    """Return int when value is a whole number, float otherwise."""
    return int(v) if float(v).is_integer() else v


def _pricing_to_dict(code: str, p: GpuPricing) -> dict[str, Any]:
    return {
        "code": code,
        "gpuName": p.gpu_name,
        "gpuExt": p.gpu_ext,
        "productName": p.product_name,
        "tier": p.product_code,
        "ppIndex": p.pp_index,
        "gpuCount": p.gpu,
        "vram": p.vram,
        "cpu": p.cpu,
        "mem": p.memory,
        "disk": p.disk,
        "priceMin": _num_out(p.price),
        "priceMax": _num_out(p.price + p.usage_price),
        "currencyUnit": p.currency_unit,
        "available": p.availability,
    }


def _gpu_display_name(p: GpuPricing) -> str:
    """Build user-facing GPU display name.

    Uses productName (like web console) with NVIDIA prefix stripped.
    Falls back to gpuName + gpuExt if productName is empty.
    """
    if p.product_name:
        return re.sub(r"^NVIDIA GeForce |^NVIDIA ", "", p.product_name)
    return f"{p.gpu_name} {p.gpu_ext}" if p.gpu_ext else p.gpu_name


@click.group("gpu", cls=OrderedGroup)
def gpu() -> None:
    """List available GPUs"""


@gpu.command("list")
@click.option("--all", "show_all", is_flag=True, default=False,
              help="Show all GPUs including unavailable")
@click.option("--service-code", default=None, envvar="GCUBE_SERVICE_CODE",
              help="Service code filter (gcube, edu, katech). [env: GCUBE_SERVICE_CODE]")
@click.pass_context
def gpu_list(ctx: click.Context, show_all: bool, service_code: str | None) -> None:
    """List available GPU types"""
    try:
        gcube_ctx = ctx.obj
        client = make_client_from_ctx(ctx)
        api = WorkloadAPI(client)

        if service_code:
            click.echo(f"Using serviceCode={service_code}", err=True)

        # CODE는 전체 목록 기준 순번 — get_indexed_gpu_pricings()가 workload
        # register/update와 동일한 기준으로 CODE를 부여하므로 항상 일치함
        indexed = api.get_indexed_gpu_pricings(service_code=service_code)
        if not show_all:
            indexed = [(code, p) for code, p in indexed if p.availability]

        # Fetch exchange rate for USD→KRW conversion (display only)
        krw_rate = 0
        if any(p.currency_unit == "USD" for _, p in indexed):
            try:
                pb = api.get_point_base()
                krw_rate = int(pb.get("krw", 0))
            except Exception:
                pass

        def _price_str(p: GpuPricing) -> str:
            price, usage = p.price, p.usage_price
            if p.currency_unit == "USD" and krw_rate > 0:
                price = round(price * krw_rate)
                usage = round(usage * krw_rate)
            return f"{round(price):,} ~ {round(price + usage):,}"

        output = gcube_ctx.output
        if output == "json":
            from gcube_cli.output.json_out import print_json

            print_json([_pricing_to_dict(code, p) for code, p in indexed])
        elif output == "yaml":
            from gcube_cli.output.yaml_out import print_yaml

            print_yaml([_pricing_to_dict(code, p) for code, p in indexed])
        else:
            if not indexed:
                msg = "No GPUs available." if not show_all else "No GPU pricings found."
                click.echo(msg)
                return
            from gcube_cli.output.table import print_table

            if show_all:
                headers = [
                    "CODE", "GPU_NAME", "TIER", "GPUs", "VRAM(GB)",
                    "CPU(Core)", "MEM(GB)", "DISK(GB)", "PRICE/HR(₩)", "AVAIL",
                ]
                rows = [
                    [
                        code,
                        _gpu_display_name(p),
                        p.product_code,
                        str(p.gpu),
                        str(p.vram),
                        str(p.cpu),
                        str(p.memory),
                        str(p.disk),
                        _price_str(p),
                        "O" if p.availability else "X",
                    ]
                    for code, p in indexed
                ]
            else:
                headers = [
                    "CODE", "GPU_NAME", "TIER", "GPUs", "VRAM(GB)",
                    "CPU(Core)", "MEM(GB)", "DISK(GB)", "PRICE/HR(₩)",
                ]
                rows = [
                    [
                        code,
                        _gpu_display_name(p),
                        p.product_code,
                        str(p.gpu),
                        str(p.vram),
                        str(p.cpu),
                        str(p.memory),
                        str(p.disk),
                        _price_str(p),
                    ]
                    for code, p in indexed
                ]
            print_table(headers, rows)
    except AuthError as e:
        click.echo(str(e), err=True)
        sys.exit(3)
    except APIError as e:
        click.echo(f"API Error [{e.code}]: {e.message}", err=True)
        sys.exit(2)
