"""Config file management for gcube CLI.

Config file: ~/.gcube/config.yaml
YAML structure:
    platform_url: https://api.gcube.ai
    client_id: ""                # Agent OAuth client ID (env GCUBE_CLIENT_ID)
    auth:
      access_token: "eyJ..."
    output: table
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class AuthConfig:
    access_token: str = ""
    user_email: str = ""


@dataclass
class GcubeConfig:
    platform_url: str = "https://api.gcube.ai"
    client_id: str = ""
    ws_url: str = "wss://console.gcube.ai:61443"
    auth: AuthConfig = field(default_factory=AuthConfig)
    output: str = "table"


class Config:
    CONFIG_DIR: Path = Path.home() / ".gcube"
    CONFIG_FILE: Path = CONFIG_DIR / "config.yaml"

    @classmethod
    def load(cls) -> GcubeConfig:
        """Load config from file. Returns defaults if file does not exist.

        Does NOT apply env var overrides — that is the cli() callback's job.
        Unknown YAML keys are silently ignored.
        """
        if not cls.CONFIG_FILE.exists():
            return GcubeConfig()

        with open(cls.CONFIG_FILE, encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        return cls._from_dict(data)

    @classmethod
    def save(cls, config: GcubeConfig) -> None:
        """Persist config to ~/.gcube/config.yaml (creates dir if needed)."""
        import os
        cls.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(cls.CONFIG_FILE, "w", encoding="utf-8") as fh:
            yaml.dump(cls._to_dict(config), fh, default_flow_style=False, allow_unicode=True)
        os.chmod(cls.CONFIG_FILE, 0o600)

    @classmethod
    def load_raw(cls) -> dict[str, Any]:
        """Load raw YAML dict without applying defaults. Returns {} if no file."""
        if not cls.CONFIG_FILE.exists():
            return {}
        with open(cls.CONFIG_FILE, encoding="utf-8") as fh:
            return yaml.safe_load(fh) or {}

    @classmethod
    def _from_dict(cls, data: dict[str, Any]) -> GcubeConfig:
        auth_raw = data.get("auth") or {}
        return GcubeConfig(
            platform_url=data.get("platform_url", "https://api.gcube.ai"),
            client_id=data.get("client_id", ""),
            ws_url=data.get("ws_url", "wss://console.gcube.ai:61443"),
            auth=AuthConfig(
                access_token=auth_raw.get("access_token", ""),
                user_email=auth_raw.get("user_email", ""),
            ),
            output=data.get("output", "table"),
        )

    @classmethod
    def _to_dict(cls, config: GcubeConfig) -> dict[str, Any]:
        result: dict[str, Any] = {
            "platform_url": config.platform_url,
            "ws_url": config.ws_url,
            "auth": {
                "access_token": config.auth.access_token,
                "user_email": config.auth.user_email,
            },
            "output": config.output,
        }
        if config.client_id:
            result["client_id"] = config.client_id
        return result
