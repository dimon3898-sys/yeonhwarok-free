"""Output formatting utilities for gcube CLI."""
from __future__ import annotations

from typing import Any

from gcube_cli.output.json_out import print_json
from gcube_cli.output.table import print_record, print_table
from gcube_cli.output.yaml_out import print_yaml


def print_output(
    data: list[dict[str, Any]] | dict[str, Any],
    format: str,
    headers: list[str] | None = None,
) -> None:
    """Dispatch to the correct formatter based on format string.

    Args:
        data: A list of dicts (for list commands) or a single dict (for describe).
        format: One of 'table', 'json', 'yaml'.
        headers: Column headers for table format. If None, uses sorted dict keys.
    """
    if format == "json":
        print_json(data)
    elif format == "yaml":
        print_yaml(data)
    else:  # table (default)
        if isinstance(data, dict):
            print_record(data)
        else:
            if not data:
                return
            if headers is None:
                headers = list(data[0].keys())
            rows = [[str(row.get(h, "")) for h in headers] for row in data]
            print_table(headers, rows)


__all__ = ["print_output", "print_table", "print_record", "print_json", "print_yaml"]
