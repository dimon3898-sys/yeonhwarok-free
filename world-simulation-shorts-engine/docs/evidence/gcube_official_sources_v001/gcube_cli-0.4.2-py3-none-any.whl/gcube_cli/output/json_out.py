"""JSON output for gcube CLI."""
from __future__ import annotations

import json
from typing import Any


def print_json(data: list[dict[str, Any]] | dict[str, Any]) -> None:
    """Print data as pretty-printed JSON to stdout."""
    print(json.dumps(data, ensure_ascii=False, indent=2))
