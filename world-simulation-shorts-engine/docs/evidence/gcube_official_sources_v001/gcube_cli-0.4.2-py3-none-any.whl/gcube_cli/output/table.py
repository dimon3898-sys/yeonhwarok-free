"""Rich table output for gcube CLI."""
from __future__ import annotations

import sys
from typing import Any

from rich.console import Console
from rich.table import Table


def _get_console() -> Console:
    """Return a Console that writes to the current sys.stdout.

    Creating the Console on each call ensures pytest's capsys fixture can
    capture the output (capsys replaces sys.stdout after module import).
    In non-tty environments (pipes, tests) rich defaults to 80 cols which
    truncates long values; use a wide fixed width instead.
    """
    width = None if sys.stdout.isatty() else 200
    return Console(file=sys.stdout, highlight=False, width=width)


def print_table(headers: list[str], rows: list[list[str]]) -> None:
    """Print a colored rich table with given headers and rows."""
    table = Table(show_header=True, header_style="bold")
    for header in headers:
        table.add_column(header)
    for row in rows:
        table.add_row(*row)
    _get_console().print(table)


def print_record(data: dict[str, Any]) -> None:
    """Print a single record as a two-column key-value rich table."""
    table = Table(show_header=True, header_style="bold")
    table.add_column("Field")
    table.add_column("Value")
    for key, value in data.items():
        table.add_row(str(key), str(value) if value is not None else "")
    _get_console().print(table)
