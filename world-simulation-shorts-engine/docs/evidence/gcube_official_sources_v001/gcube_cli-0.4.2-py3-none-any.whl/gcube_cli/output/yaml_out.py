"""YAML output for gcube CLI."""
from __future__ import annotations

from typing import Any

import yaml


def print_yaml(data: list[dict[str, Any]] | dict[str, Any]) -> None:
    """Print data as YAML to stdout."""
    print(yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False), end="")
