"""SSE client for gcube CLI — workload deploy status monitoring."""

from __future__ import annotations

import json
from collections.abc import Iterator
from dataclasses import dataclass

import httpx


@dataclass
class SSEEvent:
    event: str
    data: dict  # type: ignore[type-arg]


class SSEConnectionError(Exception):
    pass


class SSEAuthError(Exception):
    pass


class SSEReadTimeout(Exception):
    """No data received within ``read_timeout`` — the stream went idle (not a failure).

    Kept distinct from SSEConnectionError so the caller can re-check its own deadline and
    resubscribe without consuming a connection-retry budget.
    """


class SSEClient:
    def __init__(self, platform_url: str, token: str) -> None:
        self.platform_url = platform_url.rstrip("/")
        self.token = token

    def stream(
        self, namespace: str, ser: str, read_timeout: float | None = None
    ) -> Iterator[SSEEvent]:
        """Yield parsed SSE events.

        ``read_timeout`` (seconds) bounds how long a single read may block with no data;
        on expiry an :class:`SSEReadTimeout` is raised so the caller can check its own
        deadline (and keep Ctrl-C responsive). ``None`` blocks indefinitely (legacy).
        """
        url = f"{self.platform_url}/api/sse/subscribe/{namespace}/{ser}"
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
        try:
            timeout = httpx.Timeout(connect=10.0, read=read_timeout, write=None, pool=None)
            with httpx.stream("GET", url, headers=headers, timeout=timeout) as r:
                if r.status_code in (401, 403):
                    raise SSEAuthError()
                if r.status_code != 200:
                    raise SSEConnectionError(f"HTTP {r.status_code}")
                buffer = ""
                for chunk in r.iter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        message, buffer = buffer.split("\n\n", 1)
                        event = _parse_sse_message(message)
                        if event:
                            yield event
        except httpx.ReadTimeout as e:
            raise SSEReadTimeout(str(e)) from e
        except (httpx.NetworkError, httpx.RemoteProtocolError, httpx.TimeoutException) as e:
            raise SSEConnectionError(str(e)) from e


def _parse_sse_message(message: str) -> SSEEvent | None:
    """Parse a single SSE message block (event: / data: fields only)."""
    event_name = "message"
    data_str = ""
    for line in message.splitlines():
        if line.startswith("event:"):
            event_name = line[6:].strip()
        elif line.startswith("data:"):
            data_str = line[5:].strip()
    if not data_str:
        return None
    try:
        return SSEEvent(event=event_name, data=json.loads(data_str))
    except json.JSONDecodeError:
        return None
