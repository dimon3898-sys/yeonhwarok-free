"""Resource monitoring API client for gcube CLI."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from gcube_cli.api.client import APIError, Client

_GAI_BASE = "/api/workloads/gai/"


def _parse_time_interval(ti: Any) -> str | None:
    """Convert timeInterval from the API into a human-readable string.

    Handles two formats the API may return:
    - float/int: Unix timestamp in milliseconds → "YYYY-MM-DD HH:MM"
    - list [year, month, day, hour, minute]: → "YYYY-MM-DD HH:MM"
    - str: pass through as-is
    """
    if ti is None:
        return None
    if isinstance(ti, (int, float)):
        return datetime.fromtimestamp(ti / 1000).strftime("%Y-%m-%d %H:%M")
    if isinstance(ti, list) and len(ti) >= 5:
        y, m, d, h, mi = int(ti[0]), int(ti[1]), int(ti[2]), int(ti[3]), int(ti[4])
        return f"{y:04d}-{m:02d}-{d:02d} {h:02d}:{mi:02d}"
    return str(ti)


@dataclass
class ResourceUsage:
    """Resource usage snapshot for a pod."""

    gpu_name: str       # JSON: gpuName  (시간평균 응답에만 있음)
    gpu_usage: float    # JSON: gpuUsage,  단위 %
    vram_usage: float   # JSON: vramUsage, 단위 %
    vram_cap: int       # JSON: vramCap,   단위 MB
    cpu_usage: float    # JSON: cpuUsage,  단위 %
    mem_usage: float    # JSON: memUsage,  단위 %
    disk_usage: float   # JSON: diskUsage, 단위 %
    disk_occu: float    # JSON: diskOccu,  단위 MB
    net_rx: float       # JSON: netRx,     단위 kbps
    net_tx: float       # JSON: netTx,     단위 kbps
    time_interval: str | None = None  # JSON: timeInterval

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ResourceUsage:
        return cls(
            gpu_name=data.get("gpuName", ""),
            gpu_usage=round(float(data.get("gpuUsage", 0.0)), 2),
            vram_usage=round(float(data.get("vramUsage", 0.0)), 2),
            vram_cap=int(data.get("vramCap", 0)),
            cpu_usage=round(float(data.get("cpuUsage", 0.0)), 2),
            mem_usage=round(float(data.get("memUsage", 0.0)), 2),
            disk_usage=round(float(data.get("diskUsage", 0.0)), 2),
            disk_occu=round(float(data.get("diskOccu", 0.0)), 2),
            net_rx=round(float(data.get("netRx", 0.0)), 2),
            net_tx=round(float(data.get("netTx", 0.0)), 2),
            time_interval=_parse_time_interval(data.get("timeInterval")),
        )


class ResourceAPI:
    """Resource usage API client.

    2-step lookup: workload name → pod list → per-pod resource usage.

    Endpoint: GET /api/usage/avg → response key: ``usages`` (list)
    """

    def __init__(self, client: Client) -> None:
        self._client = client

    def get_workload_pods(self, workload_name: str) -> list[str]:
        """Resolve workload name to a list of running pod names."""
        data = self._client.get(f"{_GAI_BASE}{workload_name}")
        item: dict[str, Any] = data.get("workload", data.get("data", data))
        pods: list[dict[str, Any]] = item.get("pods") or []
        return [p["name"] for p in pods if p.get("name")]

    def workload(self, workload_name: str) -> dict[str, list[ResourceUsage]]:
        """Get time-series resource usage grouped by pod name.

        Returns:
            Mapping of pod_name → list[ResourceUsage].

        Raises:
            APIError: If workload has no running pods or an API call fails.
        """
        pods = self.get_workload_pods(workload_name)
        if not pods:
            raise APIError(
                status_code=404,
                code="NO_PODS",
                message=f"Workload '{workload_name}' has no running pods. Is it stopped?",
            )
        return {pod: self._get_avg(pod) for pod in pods}

    def _get_avg(self, pod_name: str) -> list[ResourceUsage]:
        """GET /api/usage/avg?pod={pod}&isPod=true"""
        data = self._client.get(
            "/api/usage/avg",
            params={"pod": pod_name, "isPod": "true"},
        )
        items: list[dict[str, Any]] = data.get("usages", [])
        return [ResourceUsage.from_dict(item) for item in items]
