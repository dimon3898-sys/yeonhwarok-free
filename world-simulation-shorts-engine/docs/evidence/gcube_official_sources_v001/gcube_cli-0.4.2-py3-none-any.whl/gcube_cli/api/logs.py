"""WebSocket log streaming for gcube workloads (PBI-016)."""

from __future__ import annotations

import click
import websockets
import websockets.exceptions


class LogsConnectionError(Exception):
    """Raised when the WebSocket connection to the log stream fails."""


class LogsAuthError(Exception):
    """Raised when the server rejects the connection due to auth failure."""


class LogStreamer:
    def __init__(self, ws_url: str, token: str) -> None:
        self.ws_url = ws_url.rstrip("/")
        self.token = token

    async def stream(self, ser: str, pod_name: str, ct_index: int = 0) -> None:
        """Open a WebSocket and stream log messages to stdout.

        The server always requires /container/{ct_index} in the URL path.
        ct_index defaults to 0 for single-container pods.
        """
        url = (
            f"{self.ws_url}/workloads/{ser}/log/{pod_name}"
            f"/container/{ct_index}?token={self.token}"
        )

        try:
            async with websockets.connect(url, close_timeout=0) as ws:
                async for message in ws:
                    click.echo(message, nl=False)
        except websockets.exceptions.ConnectionClosed:
            pass  # server closed the stream (clean close or proxy timeout)
        except websockets.exceptions.InvalidStatus as exc:
            status_code = getattr(getattr(exc, "response", None), "status_code", 0)
            if status_code in (401, 403):
                raise LogsAuthError(
                    "Token expired or invalid. Please get a new token from https://console.gcube.ai"
                ) from exc
            raise LogsConnectionError(
                f"Cannot connect to log stream (HTTP {status_code}). Check ws-url configuration."
            ) from exc
        except (OSError, websockets.exceptions.WebSocketException) as exc:
            raise LogsConnectionError(
                "Cannot connect to log stream. Check ws-url configuration."
            ) from exc
