"""SSH API client for gcube CLI."""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import httpx

from gcube_cli.api.client import APIError, Client

# Polling for SSH info readiness (matches web console: 2 s × 15 attempts)
_POLL_INTERVAL = 2
_POLL_MAX_ATTEMPTS = 15

# ``dbear_state`` value meaning the in-pod sshd finished provisioning.
_DBEAR_READY_STATE = "running"

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class SshInfo:
    ssh_url: str
    port: int
    user_name: str
    user_pwd: str
    pub_ip: str
    pod_name: str
    namespace: str
    cont_idx: int
    created_at: str
    # ``ssh_url``:``port`` is the entry gateway, which relays into the pod at
    # ``target_ip``:``target_port``. ``dbear_state`` tracks provisioning of the
    # in-pod sshd. All three are diagnostic-only for the client.
    target_ip: str = ""
    target_port: int = 0
    dbear_state: str = ""


def _parse_ssh_info(info: dict[str, Any]) -> SshInfo:
    return SshInfo(
        ssh_url=info.get("ssh_url", ""),
        port=int(info.get("port", 0)),
        user_name=info.get("user_name", ""),
        user_pwd=info.get("user_pwd", ""),
        pub_ip=info.get("pub_ip", ""),
        pod_name=info.get("pod_name", ""),
        namespace=info.get("namespace", ""),
        cont_idx=int(info.get("cont_idx", 0)),
        created_at=info.get("created_at", ""),
        target_ip=info.get("target_ip", ""),
        target_port=int(info.get("target_port", 0)),
        dbear_state=info.get("dbear_state", ""),
    )


def is_dbear_ready(info: SshInfo) -> bool:
    """Whether the pod's sshd finished provisioning. Also used by the command
    layer to size the post-registration readiness probe.

    The server answers ``register`` immediately with ``dbear_state:
    "installing"``, so receiving info does not mean the daemon accepts
    connections yet.  Backends that omit the field are treated as ready.
    """
    return not info.dbear_state or info.dbear_state == _DBEAR_READY_STATE


# ---------------------------------------------------------------------------
# API client
# ---------------------------------------------------------------------------


class SshAPI:
    def __init__(self, client: Client) -> None:
        self._client = client

    def get(self, namespace: str, pod_name: str, container: int) -> SshInfo | None:
        """GET SSH info. Returns None when not registered.

        The server may signal "not registered" as:
        - HTTP 400/404 with error envelope
        - HTTP 200 with empty/non-JSON body (EMPTY_RESPONSE)
        - HTTP 200 with JSON but no ``info`` field

        Other API errors (500/503 etc.) are re-raised.
        """
        try:
            data = self._client.get(
                f"/api/pods/ssh/user/{namespace}/{pod_name}/{container}"
            )
            info = data.get("info")
            if not info:
                return None
            return _parse_ssh_info(info)
        except APIError as e:
            if e.status_code in (400, 404) or e.code == "EMPTY_RESPONSE":
                return None
            raise  # 500/503 server errors propagated

    def register(
        self,
        pod_name: str,
        namespace: str,
        container: int,
        workload: str,
        public_ip: str,
        shell: str = "bash",
        on_poll: Callable[[], None] | None = None,
    ) -> SshInfo:
        """POST register SSH user, then poll until the daemon is provisioned.

        Two separate waits are needed, and both are handled here:

        - The server may return 200/201 with ``info`` immediately, or return
          an empty/204 response while it creates the record.
        - Even once ``info`` exists, ``dbear_state`` is typically
          ``"installing"`` — the pod's sshd is not up yet, so connecting
          straight away fails with a relayed ``Connection refused``.

        Polls every 2 s up to 15 times, like the web console.  On exhaustion
        the last known info is returned rather than raising: connecting may
        still work, and the caller probes readiness before handing over.

        ``on_poll`` is called before each poll attempt (for progress display).
        """
        info: SshInfo | None = None
        try:
            data = self._client.post(
                "/api/pods/ssh/user/register",
                json={
                    "podName": pod_name,
                    "namespace": namespace,
                    "container": container,
                    "workload": workload,
                    "publicIp": public_ip,
                    "shell": shell,
                },
            )
            raw = data.get("info")
            if raw:
                info = _parse_ssh_info(raw)
        except APIError as e:
            if e.code != "EMPTY_RESPONSE":
                raise

        for _ in range(_POLL_MAX_ATTEMPTS):
            if info is not None and is_dbear_ready(info):
                return info
            if on_poll:
                on_poll()
            time.sleep(_POLL_INTERVAL)
            try:
                polled = self.get(namespace, pod_name, container)
            except APIError:
                # While provisioning runs the server may answer with a transient
                # error envelope (e.g. "SSH Connection Info error"), which is not
                # one of the "not registered" shapes get() absorbs.  This is a
                # wait loop, so any failure just means "not ready yet".
                continue
            if polled is not None:
                info = polled

        if info is not None:
            return info  # still provisioning — caller warns and tries anyway

        raise APIError(0, "SSH_TIMEOUT", "SSH info not ready after polling. Try again.")

    def delete(self, namespace: str, pod_name: str, container: int) -> bool:
        """DELETE SSH info. Returns True on success."""
        try:
            self._client.delete(
                f"/api/pods/ssh/user/{namespace}/{pod_name}/{container}/delete"
            )
            return True
        except APIError:
            return False


# ---------------------------------------------------------------------------
# Public IP detection
# ---------------------------------------------------------------------------

# Each source returns JSON with an "ip" field.
_IP_SOURCES = [
    "https://api.ip.pe.kr/json/",
    "https://api.ipify.org?format=json",
]


def detect_public_ip() -> str | None:
    """Detect public IP via external services (fallback chain)."""
    for url in _IP_SOURCES:
        try:
            resp = httpx.get(url, timeout=3)
            if resp.status_code == 200:
                ip = resp.json().get("ip")
                if ip:
                    return str(ip).strip()
        except Exception:
            continue
    return None
