"""Credential management API client for gcube CLI."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from gcube_cli.api.client import Client


@dataclass
class Credential:
    """Container image registry credential."""

    owner: str
    category: str       # 항상 "repo"
    cloud: str          # docker | github | harbor | aws | huggingface | quay
    acc_key: str        # JSON: accKey (username)
    sec_key: str        # JSON: secKey (token/password)
    region: str | None = None        # AWS ECR region
    registry_id: str | None = None   # JSON: registryId (AWS ECR only)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Credential:
        return cls(
            owner=data.get("owner", ""),
            category=data.get("category", ""),
            cloud=data.get("cloud", ""),
            acc_key=data.get("accKey", data.get("acc_key", "")),
            sec_key=data.get("secKey", data.get("sec_key", "")),
            region=data.get("region") or None,
            registry_id=data.get("registryId", data.get("registry_id")) or None,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to camelCase JSON dict for the API request."""
        return {
            "owner": self.owner,
            "category": self.category,
            "cloud": self.cloud,
            "accKey": self.acc_key,
            "secKey": self.sec_key,
            "region": self.region or "",
            "registryId": self.registry_id or "",
        }


class CredentialAPI:
    """High-level Credential API client."""

    def __init__(self, client: Client) -> None:
        self._client = client

    def list(self, owner: str) -> list[Credential]:
        """GET /api/credential/list?owner={email}"""
        data = self._client.get("/api/credential/list", params={"owner": owner})
        items: list[dict[str, Any]] = data.get("credentials", data.get("data", data.get("items", [])))
        return [Credential.from_dict(item) for item in items]

    def create(self, cred: Credential) -> Credential:
        """POST /api/credential/register"""
        data = self._client.post("/api/credential/register", json=cred.to_dict())
        item: dict[str, Any] = data.get("data", data)
        return Credential.from_dict(item) if isinstance(item, dict) and item else cred

    def delete(self, cloud: str) -> None:
        """DELETE /api/credential/delete/repo/{cloud}"""
        self._client.delete(f"/api/credential/delete/repo/{cloud}")
