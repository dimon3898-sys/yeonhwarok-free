"""Point balance and usage API client for gcube CLI (PBI-013)."""

from __future__ import annotations

import calendar
import datetime
from dataclasses import dataclass
from typing import Any

from gcube_cli.api.client import Client


@dataclass
class PointStatus:
    available_point: int
    charge_point: int
    spend_point: int
    net_point: int
    is_blocked: bool
    is_alarm: bool

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PointStatus:
        points: dict[str, Any] = data.get("points", data)
        return cls(
            available_point=int(points.get("availablePoint", 0)),
            charge_point=int(points.get("chargePoint", 0)),
            spend_point=int(points.get("spendPoint", 0)),
            net_point=int(points.get("netPoint", 0)),
            is_blocked=bool(points.get("isBlocked", False)),
            is_alarm=bool(points.get("isAlarm", False)),
        )


@dataclass
class PointSpendSummary:
    total_spend: int
    prev_month_spend: int
    this_month_spend: int

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PointSpendSummary:
        points: dict[str, Any] = data.get("points", data)
        total = points.get("totalSpend", {})
        prev = points.get("prevMonthSpend", {})
        this = points.get("thisMonthSpend", {})
        return cls(
            total_spend=int(total.get("point", 0) if isinstance(total, dict) else total),
            prev_month_spend=int(prev.get("point", 0) if isinstance(prev, dict) else prev),
            this_month_spend=int(this.get("point", 0) if isinstance(this, dict) else this),
        )


@dataclass
class DailySpend:
    date: str
    gpu_point: float
    krw_gpu_amount: int
    krw_gpu_unit_amount: int
    krw_gpu_usage_amount: int
    gpu_usage: float
    net_rx: float
    net_tx: float

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DailySpend:
        return cls(
            date=str(data.get("date", "")),
            gpu_point=float(data.get("gpuPoint") or 0),
            krw_gpu_amount=int(data.get("krwGpuAmount") or 0),
            krw_gpu_unit_amount=int(data.get("krwGpuUnitAmount") or 0),
            krw_gpu_usage_amount=int(data.get("krwGpuUsageAmount") or 0),
            gpu_usage=float(data.get("gpuUsage") or 0),
            net_rx=float(data.get("netRx") or 0),
            net_tx=float(data.get("netTx") or 0),
        )


def _month_range(month: str) -> tuple[str, str]:
    """'YYYY-MM' → ('YYYY-MM-01', 'YYYY-MM-DD') 말일 계산."""
    year, mon = int(month[:4]), int(month[5:7])
    last_day = calendar.monthrange(year, mon)[1]
    return f"{year:04d}-{mon:02d}-01", f"{year:04d}-{mon:02d}-{last_day:02d}"


def _current_month_range() -> tuple[str, str]:
    today = datetime.date.today()
    return f"{today.year:04d}-{today.month:02d}-01", today.strftime("%Y-%m-%d")


# status API (/api/point/status) 에서 표시할 필드만 허용
_STATUS_ALLOWLIST = frozenset({
    "availablePoint", "chargePoint", "spendPoint", "netPoint",
    "isBlocked", "isAlarm",
})

# daily spends JSON 출력에 포함할 필드 (allowlist)
# GCUBE 단가 기준. 공급자 단가(point/krwAmount 등)·리소스 상세·내부 필드 제외
_SPENDING_ALLOWLIST = frozenset({
    "date", "gpuPoint", "gpuName", "gpuUsage", "workload",
    "krwGpuAmount", "krwGpuUnitAmount", "krwGpuUsageAmount",
    "usdGpuAmount", "usdGpuUnitAmount", "usdGpuUsageAmount",
    "netRx", "netTx",
})


def _filter_status_json(raw: dict[str, Any]) -> dict[str, Any]:
    """status JSON: 허용 목록 필드만 출력."""
    points = raw.get("points", {})
    return {"points": {k: v for k, v in points.items() if k in _STATUS_ALLOWLIST}}


def _filter_spend_summary_json(raw: dict[str, Any]) -> dict[str, Any]:
    """spend/status JSON: 각 항목의 point 값만 추출하여 flat 구조로 반환."""
    points = raw.get("points", {})

    def _pt(key: str) -> int:
        val = points.get(key, {})
        return int(val.get("point", 0) if isinstance(val, dict) else val)

    return {
        "totalSpend": _pt("totalSpend"),
        "prevMonthSpend": _pt("prevMonthSpend"),
        "thisMonthSpend": _pt("thisMonthSpend"),
    }


def _filter_spending_json(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """daily spends JSON: GCUBE 단가 + 기본 정보 필드만 허용 (allowlist)."""
    return [{k: v for k, v in item.items() if k in _SPENDING_ALLOWLIST} for item in items]


class PointAPI:
    def __init__(self, client: Client) -> None:
        self._client = client

    def status(self, owner: str) -> tuple[PointStatus, dict[str, Any]]:
        """GET /api/point/status?owner={email}. Returns (model, raw_data)."""
        raw = self._client.get("/api/point/status", params={"owner": owner})
        data: dict[str, Any] = raw.get("data", raw)
        return PointStatus.from_dict(data), data

    def spend_summary(self, owner: str) -> tuple[PointSpendSummary, dict[str, Any]]:
        """GET /api/point/spend/status?owner={email}. Returns (model, raw_data)."""
        raw = self._client.get("/api/point/spend/status", params={"owner": owner})
        data: dict[str, Any] = raw.get("data", raw)
        return PointSpendSummary.from_dict(data), data

    def daily_spends(
        self,
        owner: str,
        workload: int | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
    ) -> tuple[list[DailySpend], list[dict[str, Any]]]:
        """GET /api/point/daily/spends. Returns (models, raw_items)."""
        params: dict[str, Any] = {"owner": owner}
        if workload is not None:
            params["workload"] = workload
        if start_time:
            params["startTime"] = start_time
        if end_time:
            params["endTime"] = end_time
        raw = self._client.get("/api/point/daily/spends", params=params)
        data: dict[str, Any] = raw.get("data", raw)
        items: list[dict[str, Any]] = data.get("pointSpends", [])
        return [DailySpend.from_dict(i) for i in items], items
