"""User API client for gcube CLI."""

from __future__ import annotations

from dataclasses import dataclass

from gcube_cli.api.client import Client


@dataclass
class UserInfo:
    email: str
    namespace: str


class UserAPI:
    def __init__(self, client: Client) -> None:
        self.client = client

    def get_info(self, email: str) -> UserInfo:
        data = self.client.get(f"/api/users/{email}")
        user = data["user"]
        return UserInfo(email=user["email"], namespace=user["namespace"])

    def get_namespace(self, email: str) -> str:
        return self.get_info(email).namespace
