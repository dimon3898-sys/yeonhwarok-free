"""Shared parsing helpers for API response payloads.

The gcube API is loosely typed: numeric fields arrive as ints, floats, numeric
strings, or ``null`` depending on the endpoint, and timestamps come in two
different shapes.  These helpers give every ``from_dict()`` the same defensive
behaviour so a single odd field cannot crash a command.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def to_int(v: Any) -> int:
    """Parse an int, falling back to 0 for null / non-numeric input."""
    if v is None:
        return 0
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def to_float(v: Any) -> float:
    """Parse a float, falling back to 0.0 (e.g. USD prices: 1.99)."""
    if v is None:
        return 0.0
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def parse_server_dt(raw: Any) -> datetime | None:
    """Parse a server timestamp string into an aware datetime, or None.

    The platform sends two string shapes:

    - naive ``"YYYY-MM-DD HH:MM:SS"``     — no offset, so it is UTC by convention
    - ISO-8601 with an explicit offset    — e.g. ``"...T04:51:01+00:00"``

    Naive values get ``tzinfo=UTC`` attached. Every caller that displays or
    subtracts a server timestamp goes through here, so the "naive means UTC"
    assumption lives in exactly one place — duplicating it is how
    ``api/team.py`` ended up rendering UTC as if it were local.
    """
    if not raw or not isinstance(raw, str):
        return None
    try:
        dt = datetime.fromisoformat(raw)
    except (ValueError, TypeError):
        return None
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


def fmt_date(v: Any) -> str:
    """Convert an API UTC timestamp to local ``'YYYY-MM-DD HH:MM:SS'``.

    Accepts the two shapes the platform sends:

    - list ``[y, m, d, h, mi, s]``            — workload createdAt/deployAt/closeAt
    - str  ``"YYYY-MM-DD HH:MM:SS"``          — pod startTime, team createdAt/joinedAt

    Both are treated as naive UTC and converted to the local timezone.  The
    server never sends an offset, so displaying the raw value would be wrong by
    the local UTC offset (9 hours in KST).  Unparseable strings are returned
    unchanged rather than discarded.
    """
    if isinstance(v, list) and len(v) >= 3:
        y, mo, d = v[0], v[1], v[2]
        h = v[3] if len(v) > 3 else 0
        mi = v[4] if len(v) > 4 else 0
        s = v[5] if len(v) > 5 else 0
        dt = datetime(y, mo, d, h, mi, s, tzinfo=timezone.utc)
        return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(v, str) and v:
        dt_parsed = parse_server_dt(v)
        if dt_parsed is None:
            return v          # unparseable: show it rather than blank it
        return dt_parsed.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    # Anything else (ints, dicts) is stringified rather than dropped, so an
    # unexpected shape still shows something instead of a blank cell.
    return "" if v is None else str(v)
