"""Team API client and data models for gcube CLI (PBI-023)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from gcube_cli.api._util import fmt_date, to_float, to_int
from gcube_cli.api.client import Client

# Numeric parsing is shared with api/workload.py -- see api/_util.py.
_int = to_int
_num = to_float


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class Team:
    team_id: int
    name: str
    description: str
    owner_email: str
    namespace: str
    status: str          # 'ACTIVE' | 'ARCHIVED'
    created_at: str
    updated_at: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> Team:
        return cls(
            team_id=_int(d.get("teamId")),
            name=d.get("name", ""),
            description=d.get("description") or "",
            owner_email=d.get("ownerEmail", ""),
            namespace=d.get("namespace") or "",
            status=d.get("status", ""),
            # The server sends naive UTC ("2026-08-14 08:27:07"); showing it raw
            # would be off by the local UTC offset (9h in KST).
            created_at=fmt_date(d.get("createdAt")),
            updated_at=fmt_date(d.get("updatedAt")),
        )


@dataclass
class MyTeam:
    team: Team
    my_role: str         # 'OWNER' | 'ADMIN' | 'VIEWER'
    member_count: int

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> MyTeam:
        team_data: dict[str, Any] = d.get("team") or {}
        return cls(
            team=Team.from_dict(team_data),
            my_role=d.get("myRole", ""),
            member_count=_int(d.get("memberCount")),
        )


@dataclass
class TeamMember:
    team_id: int
    email: str
    name: str
    role: str            # 'OWNER' | 'ADMIN' | 'VIEWER'
    status: str
    joined_at: str

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TeamMember:
        return cls(
            team_id=_int(d.get("teamId")),
            email=d.get("email", ""),
            name=d.get("name") or "",
            role=d.get("role", ""),
            status=d.get("status", ""),
            joined_at=fmt_date(d.get("joinedAt")),
        )


@dataclass
class TeamPointStatus:
    team_id: int
    name: str
    owner_email: str
    status: str
    my_role: str
    charged_point: float
    used_point: float
    network_point: float
    workload_count: int
    member_count: int

    @property
    def remaining_point(self) -> float:
        return self.charged_point - self.used_point - self.network_point

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> TeamPointStatus:
        return cls(
            team_id=_int(d.get("teamId")),
            name=d.get("name", ""),
            owner_email=d.get("ownerEmail", ""),
            status=d.get("status", ""),
            my_role=d.get("myRole", ""),
            charged_point=_num(d.get("chargedPoint")),
            used_point=_num(d.get("usedPoint")),
            network_point=_num(d.get("networkPoint")),
            workload_count=_int(d.get("workloadCount")),
            member_count=_int(d.get("memberCount")),
        )


# ---------------------------------------------------------------------------
# API client
# ---------------------------------------------------------------------------


class TeamAPI:
    def __init__(self, client: Client) -> None:
        self._client = client

    def list_my_teams(self) -> list[MyTeam]:
        """GET /api/team -> teams[]"""
        raw = self._client.get("/api/team")
        items: list[dict[str, Any]] = raw.get("teams", [])
        return [MyTeam.from_dict(i) for i in items]

    def get_detail(self, team_id: int) -> tuple[Team, str, list[TeamMember]]:
        """GET /api/team/{teamId} -> (team, myRole, members[])"""
        raw = self._client.get(f"/api/team/{team_id}")
        team = Team.from_dict(raw.get("team") or {})
        my_role: str = raw.get("myRole", "")
        members = [TeamMember.from_dict(m) for m in raw.get("members", [])]
        return team, my_role, members

    def create(self, name: str, description: str | None = None) -> Team:
        """POST /api/team, body: { name, description }"""
        body: dict[str, Any] = {"name": name, "description": description}
        raw = self._client.post("/api/team", json=body)
        return Team.from_dict(raw.get("team") or {})

    def get_points(self) -> list[TeamPointStatus]:
        """GET /api/team/point -> points[]"""
        raw = self._client.get("/api/team/point")
        items: list[dict[str, Any]] = raw.get("points", [])
        return [TeamPointStatus.from_dict(i) for i in items]
