from __future__ import annotations

from typing import Any

import click


class _NoTrailingPeriodHelp:
    """Drop the trailing period from Click's built-in ``--help`` text.

    Click hardcodes "Show this message and exit." Every gcube help string is a
    period-free sentence fragment, so strip it to keep the option list uniform.
    """

    def get_help_option(self, ctx: click.Context) -> click.Option | None:
        option: click.Option | None = super().get_help_option(ctx)  # type: ignore[misc]
        if option is not None and option.help and option.help.endswith("."):
            option.help = option.help[:-1]
        return option


class GcubeCommand(_NoTrailingPeriodHelp, click.Command):
    """click.Command carrying gcube's help-text conventions."""


class OrderedGroup(_NoTrailingPeriodHelp, click.Group):
    """click.Group that lists commands in insertion order and supports aliases."""

    command_class = GcubeCommand

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._aliases: dict[str, str] = {}
        self._reverse_aliases: dict[str, list[str]] = {}
        self._deprecated_aliases: dict[str, str] = {}

    def add_alias(
        self,
        alias: str,
        command_name: str,
        *,
        hidden: bool = False,
        deprecated: bool = False,
    ) -> None:
        """Register *alias* as an alternative name for *command_name*.

        hidden: keep the alias resolvable but omit it from help output. Use for
            legacy/compatibility names you don't want to advertise.
        deprecated: print a stderr notice when the alias is used. Implies the
            alias should be phased out; typically combined with ``hidden``.
        """
        self._aliases[alias] = command_name
        if deprecated:
            self._deprecated_aliases[alias] = command_name
        if hidden:
            return
        self._reverse_aliases.setdefault(command_name, []).append(alias)
        cmd = self.commands.get(command_name)
        if cmd is not None:
            existing: list[str] = getattr(cmd, "_command_aliases", [])
            cmd._command_aliases = [*existing, alias]  # type: ignore[attr-defined]

    def format_help(self, ctx: click.Context, formatter: click.HelpFormatter) -> None:
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        aliases: list[str] | None = getattr(self, "_command_aliases", None)
        if aliases:
            with formatter.section("Aliases"):
                formatter.write_text(f"{self.name}, {', '.join(aliases)}")
        # format_options calls format_commands internally in Click
        self.format_options(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        target = self._aliases.get(cmd_name)
        if target is not None:
            if cmd_name in self._deprecated_aliases:
                click.echo(
                    f"Warning: '{cmd_name}' has been renamed to '{target}'; "
                    f"please use '{target}' instead.",
                    err=True,
                )
            cmd_name = target
        return super().get_command(ctx, cmd_name)

    def list_commands(self, ctx: click.Context) -> list[str]:  # noqa: ARG002
        return list(self.commands)

    def format_commands(
        self, ctx: click.Context, formatter: click.HelpFormatter
    ) -> None:
        rows: list[tuple[str, str]] = []
        for name in self.list_commands(ctx):
            cmd = self.commands.get(name)
            if cmd is None or cmd.hidden:
                continue
            help_text = cmd.get_short_help_str(limit=formatter.width)
            aliases = self._reverse_aliases.get(name)
            if aliases:
                name = f"{name} ({', '.join(aliases)})"
            rows.append((name, help_text))
        if rows:
            with formatter.section("Commands"):
                formatter.write_dl(rows)
