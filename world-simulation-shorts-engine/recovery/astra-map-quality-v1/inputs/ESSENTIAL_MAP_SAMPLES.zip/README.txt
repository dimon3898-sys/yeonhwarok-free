WORLD ENGINE — ESSENTIAL MAP SAMPLES
검증일: 2026-10-14

먼저 ESSENTIAL_DATA_REPORT.md를 읽고, 구현 담당자에게 CODEX_HANDOFF.md와 DATA_MANIFEST.json을 전달하세요.

실제 확보한 데이터는 3종입니다.
1. Copernicus GLO-30 AWS 2021 배포본: 한국 산악 지역 높이 크롭 TIFF
2. GEBCO_2026: 한국 동해안 주변의 지형·수심 부분 격자 NetCDF
3. NASA Blue Marble Next Generation (August 2004): 한반도 PNG 및 좌표 sidecar

파일 자체의 검증 범위: 공식 응답 취득, 파싱, 좌표·값 보존, SHA-256 및 시각적 이상 유무 확인.
WORLD ENGINE 렌더러 호환성·완성 영상 품질·실측 정확도 검증은 수행하지 않았습니다.
기존 WORLD ENGINE 코드, 기존 manifest, FINAL은 수정하지 않았습니다.

DATA_MANIFEST.json: 정확한 bbox/CRS/수직기준/버전/해상도/파일크기/SHA-256/URL/상태
DATA_MANIFEST.csv: 같은 주요 정보를 표로 제공
OFFICIAL_URLS.txt: 복사해서 쓸 수 있는 공식 페이지·취득 주소
licenses/: 라이선스 근거, Copernicus 라이선스 PDF, 필수 출처 고지
provenance/: 실제 취득·메타데이터·검증 기록; GEBCO 원격 ASCII 부분 응답
samples/: 사용 가능한 소형 지역 샘플

PNG는 .pgw 및 .prj와 함께 사용하세요. bbox 순서는 manifest 기준입니다.
샘플을 재배포하거나 영상을 공개할 때 licenses/ATTRIBUTION.txt의 해당 고지를 유지하세요.

SHA256SUMS.txt는 이 파일을 포함한 패키지 내용의 SHA-256입니다(자기 자신 제외).
ZIP 자체의 SHA-256은 ZIP 외부 ESSENTIAL_MAP_SAMPLES.zip.sha256 파일을 사용하세요.
해시는 이번에 내려받은 바이트의 무결성을 확인하기 위한 것으로 공급기관의 전자서명이나 정확도 보증이 아닙니다.

자료를 식별만 하고 실제로 내려받지 않은 추가 경로:
- 동일 Copernicus GLO-30의 CDSE 등록 API 최신판 경로
- 같은 NASA 레이어의 WMTS 타일 경로(메타데이터만 확인)
선택된 3종 중 SAMPLE NOT DOWNLOADED인 항목은 없습니다.
