# 사용 조건 근거 — 2026-10-14 확인

## Copernicus GLO-30

- 기관 공식 사양/고지: https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM
- 공개 미러 배포 정보: https://registry.opendata.aws/copernicus-dem/
- 배포자 문서의 라이선스 PDF: https://docs.sentinel-hub.com/api/latest/static/files/data/dem/resources/license/License-COPDEM-30.pdf
- 원문 PDF 사본: `License-COPDEM-30.pdf` (다운로드 200 확인).
- 근거: Article 4의 복제·배포·공중 전달·가공 권리, Article 5의 무료 조건. 비상업 목적 한정이 없어 이번 상업 영상·캐시·크롭 배포가 허용된다고 판단한다.
- Article 6: 출처와 가공 여부를 고지하고, 면책 및 후속 사용자 의무를 전달하며 기관의 보증을 암시하지 않는다. 이번 샘플에는 modified notice를 적용했다.
- 이 권리는 GLO-30에 관한 것으로, 제한된 10m 제품의 공개 이용까지 허용하는 것이 아니다.

## GEBCO

- 조건 원문: https://www.gebco.net/data-products/gridded-bathymetry/terms-of-use
- 짧은 근거: “Commercially exploit The GEBCO Grid”
- 공개 조건은 복제·게시·배포·변환·상업 활용을 명시적으로 허용한다. 원자료 격자의 복사·지역 캐시·파생 에셋 제공이 가능하다.
- 출처 표시, 기관의 공식 지위/보증 암시 금지, 출처·자료 왜곡 금지. 항해·해상 안전용 사용 금지. underlying survey 원자료 자체에 대한 허가로 확대하지 않는다.
- 사용한 판의 인용: https://doi.org/10.5285/4f68d5c7-45eb-f999-e063-7086abc036fa

## NASA Blue Marble

- 개별 자료·크레딧: https://science.nasa.gov/earth/earth-observatory/blue-marble-next-generation/
- 상업 활용 지침: https://www.nasa.gov/nasa-brand-center/images-and-media/
- GIBS API: https://nasa-gibs.github.io/gibs-api-docs/access-basics/
- 개별 페이지는 사용·재게시 시 “NASA Earth Observatory” 표기를 요청한다. NASA 지침은 사실·정보 전달 목적의 편집적 상업 이용을 허용한다. 이번 지도 영상 및 그 제작용 지역 에셋 전달은 이 범위로 판단했다.
- NASA의 지지·보증으로 표현하지 않는다. NASA 로고, 인물, 별도 표시된 제3자 저작물의 권리는 이 자료 사용 허가와 별개다. 본 샘플에 로고·인물은 없다.
- 캐시의 구체적 용량 제한, API의 정량 요청 한도·SLA는 확인 불가. 대량 무제한 수집 권리로 해석하지 않는다.

정확한 의무 고지는 `ATTRIBUTION.txt`에 있다. 원라이선스를 새 CC 라이선스로 바꾸거나 데이터 전체를 자체 저작물로 표시하지 않는다.
