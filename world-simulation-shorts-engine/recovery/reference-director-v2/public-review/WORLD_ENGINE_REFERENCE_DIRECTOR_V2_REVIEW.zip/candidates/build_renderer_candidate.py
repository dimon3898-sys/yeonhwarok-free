from pathlib import Path
import difflib,hashlib,json
ns=Path(__file__).resolve().parents[1]
root=ns.parents[2]
source=root/'world-simulation-shorts-engine/web/map_infographic_v1/renderer.mjs'
original=source.read_text(); s=original
assert hashlib.sha256(original.encode()).hexdigest()=='e4c80a478fe7b849c9f260eaffa436bea32af78596673dd2e046e25412363b38'

def replace(old,new):
 global s
 assert s.count(old)==1, (old[:100],s.count(old))
 s=s.replace(old,new)

replace("import {assertLocalDetailAdmission} from './local_detail_admission.mjs';", "import {assertLocalDetailAdmission,terrainDetailDescriptor} from './local_detail_admission.mjs';")
replace("export const THEME_VERSION = 'terrain-material-1';", "export const THEME_VERSION = 'terrain-material-1';\nexport const REFERENCE_SIMILARITY_SCHEMA = 'REFERENCE_SIMILARITY_2D_V1';")
replace("uniform vec4 bounds, tileBounds;", """uniform vec4 bounds, tileBounds;
// Opt-in inverse geographic sampling. GIS targets stay in current-view UVs.
uniform int similarityEnabled;
uniform vec2 similarityCenterQ, similarityAngle;
uniform float similarityScale;
uniform vec3 similarityOrigin;
uniform vec2 similarityTileSpanQ, similarityTileCenterUV;""")
replace(" vec2 geo=mix(bounds.xy,bounds.zw,vUv);", " vec2 geo=mix(bounds.xy,bounds.zw,vUv);\n vec2 activeSimilarityDeltaQ=vec2(0.);")
replace(" vec2 guv=vec2((geo.x+180.)/360.,(geo.y+90.)/180.);", """ if(globeProjection==0&&similarityEnabled==1){
  vec2 d=vec2((vUv.x-.5)*1080.,(.5-vUv.y)*1920.)/similarityScale;
  vec2 deltaQ=vec2(similarityAngle.x*d.x+similarityAngle.y*d.y,-similarityAngle.y*d.x+similarityAngle.x*d.y);
  vec2 q=similarityCenterQ+deltaQ;
  activeSimilarityDeltaQ=deltaQ;
  geo=vec2(similarityOrigin.x+q.x/similarityOrigin.z,similarityOrigin.y-q.y);
 }
 vec2 guv=vec2((geo.x+180.)/360.,(geo.y+90.)/180.);""")
replace(" vec2 tuv=(geo-tileBounds.xy)/(tileBounds.zw-tileBounds.xy);", """ vec2 tuv=(geo-tileBounds.xy)/(tileBounds.zw-tileBounds.xy);
 // Relative projected source coordinates avoid subtracting large absolute
 // latitudes at fine local RGB detail; default/world sampling is unchanged.
 if(globeProjection==0&&similarityEnabled==1)tuv=similarityTileCenterUV+vec2(activeSimilarityDeltaQ.x/similarityTileSpanQ.x,-activeSimilarityDeltaQ.y/similarityTileSpanQ.y);""")
needle="export function polygons(record){"
replace(needle,"""// Only the explicitly selected path fetches/hash-binds real source bytes.
// The established default TextureLoader path above is unchanged.
async function verifiedSimilarityTexture(asset){
 if(!/^[a-f0-9]{64}$/i.test(asset?.sha256??''))throw Error('SIMILARITY_TERRAIN_SHA256_REQUIRED');
 const response=await fetch(asset.url);if(!response.ok)throw Error('SIMILARITY_TERRAIN_SOURCE_UNAVAILABLE');
 const bytes=await response.arrayBuffer();
 const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))).map(v=>v.toString(16).padStart(2,'0')).join('');
 if(digest.toLowerCase()!==asset.sha256.toLowerCase())throw Error('SIMILARITY_TERRAIN_SHA256_MISMATCH');
 const url=URL.createObjectURL(new Blob([bytes]));
 try{const result=await texture(url);result.userData.verifiedSimilaritySource={sha256:digest,bytes:bytes.byteLength};return result;}
 finally{URL.revokeObjectURL(url);}
}
export function polygons(record){""")
replace("contextTerrain=null,contextGeometries=[]}){\n assertLocalDetailAdmission", """contextTerrain=null,contextGeometries=[],projectionMode=null}){
 const similarityOptIn=projectionMode===REFERENCE_SIMILARITY_SCHEMA;
 if(projectionMode!==null&&!similarityOptIn)throw Error('SIMILARITY_PROJECTION_MODE_UNSUPPORTED');
 if(similarityOptIn&&(plan.framing?.projection!=='REGIONAL_EQUIRECTANGULAR'||!Array.isArray(plan.framing.bounds)||plan.framing.bounds.length!==4||!plan.framing.bounds.every(Number.isFinite)||plan.framing.bounds[0]<-180||plan.framing.bounds[2]>180||plan.framing.bounds[0]>=plan.framing.bounds[2]||plan.framing.bounds[2]-plan.framing.bounds[0]>180||plan.framing.bounds[1]<-85||plan.framing.bounds[3]>85||plan.framing.bounds[1]>=plan.framing.bounds[3]))throw Error('SIMILARITY_FLAT_UNWRAPPED_REGIONAL_PROJECTION_REQUIRED');
 const similarityAsset=similarityOptIn?structuredClone(plan.assets.terrain):null;
 const similarityMinimumBounds=similarityOptIn?[...(layoutPlan??plan).framing.bounds]:null;
 const similarityInitialMinimumBounds=similarityOptIn?[...plan.framing.bounds]:null;
 if(similarityOptIn&&(!Array.isArray(similarityMinimumBounds)||similarityMinimumBounds.length!==4||!similarityMinimumBounds.every(Number.isFinite)||similarityMinimumBounds[0]>=similarityMinimumBounds[2]||similarityMinimumBounds[1]>=similarityMinimumBounds[3]))throw Error('SIMILARITY_ADMITTED_MINIMUM_INVALID');
 assertLocalDetailAdmission""")
replace(" assertLocalDetailAdmission(plan,heightSource);", " assertLocalDetailAdmission(plan,heightSource);\n if(similarityOptIn&&layoutPlan&&layoutPlan!==plan)assertLocalDetailAdmission(layoutPlan,heightSource);")
replace(",b=plan.framing.bounds,c=", ",b=similarityOptIn?[...plan.framing.bounds]:plan.framing.bounds,c=")
replace(" const [regional,global,topo,wide]=await Promise.all([texture(plan.assets.terrain.url),texture(plan.assets.global.url),texture(plan.assets.topo.url),contextTerrain?texture(contextTerrain.url):Promise.resolve(null)]);", " const [regional,global,topo,wide]=await Promise.all([similarityOptIn?verifiedSimilarityTexture(similarityAsset):texture(plan.assets.terrain.url),texture(plan.assets.global.url),texture(plan.assets.topo.url),contextTerrain?texture(contextTerrain.url):Promise.resolve(null)]);")
replace(" const uniforms={terrain:", " const uniforms={similarityEnabled:{value:0},similarityCenterQ:{value:new THREE.Vector2()},similarityScale:{value:1},similarityAngle:{value:new THREE.Vector2(1,0)},similarityOrigin:{value:new THREE.Vector3(c,lat,cos)},similarityTileSpanQ:{value:new THREE.Vector2(((similarityAsset??plan.assets.terrain).bounds[2]-(similarityAsset??plan.assets.terrain).bounds[0])*cos,(similarityAsset??plan.assets.terrain).bounds[3]-(similarityAsset??plan.assets.terrain).bounds[1])},similarityTileCenterUV:{value:new THREE.Vector2()},terrain:")
replace(" let currentReveal={...revealDefaults},currentBounds=[...b],primaryMaterialReveal=1;", """ let currentReveal={...revealDefaults},currentBounds=[...b],primaryMaterialReveal=1;
 let similarityReady=true,similarityState=null;
 const similarityError=(code,message=code)=>Object.assign(Error(message),{code,category:'DATA_ADMISSION'});
 const finitePoint=p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite);
 const float32HalfUlp=x=>x===0?2**-150:Math.max(2**-150,2**(Math.floor(Math.log2(Math.abs(x)))-24));
 const validGeoBounds=(a,source=false)=>Array.isArray(a)&&a.length===4&&a.every(Number.isFinite)&&a[0]>=-180&&a[2]<=180&&a[1]>=(source?-90:-85)&&a[3]<=(source?90:85)&&a[0]<a[2]&&a[1]<a[3]&&a[2]-a[0]<=(source?360:180);
 function projectionDescriptor(){
  if(isGlobe)throw similarityError('SIMILARITY_GLOBE_TRANSITION_UNSUPPORTED');
  return Object.freeze({schema:'NATIVE_FLAT_Q_MODEL_V1',initialBounds:Object.freeze([...b]),center:Object.freeze([c,lat]),standardParallelCosine:cos});
 }
 function inverseScreen(pixel){
  if(isGlobe)throw similarityError('SIMILARITY_GLOBE_INVERSE_UNSUPPORTED');
  if(!finitePoint(pixel))throw similarityError('SIMILARITY_FINITE_SCREEN_POINT_REQUIRED');
  const point=new THREE.Vector3(pixel[0]/1080*2-1,1-pixel[1]/1920*2,0).unproject(camera);
  return [c+point.x/cos,lat+point.y];
 }
 function sourceEnvelope(){
  const corners=[[0,0],[1080,0],[1080,1920],[0,1920]].map(inverseScreen);
  return {corners,bounds:[Math.min(...corners.map(p=>p[0])),Math.min(...corners.map(p=>p[1])),Math.max(...corners.map(p=>p[0])),Math.max(...corners.map(p=>p[1]))],method:'ACTUAL_NATIVE_CAMERA_INVERSE_FOUR_VIEWPORT_CORNERS'};
 }
 function updateSimilarity(value){
  if(!similarityOptIn)throw similarityError('SIMILARITY_EXPLICIT_OPT_IN_REQUIRED');
  if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).some(k=>!['centerQ','scale','angleDegrees'].includes(k))||!finitePoint(value.centerQ)||!Number.isFinite(value.scale)||value.scale<=0||!Number.isFinite(value.angleDegrees))throw similarityError('SIMILARITY_POSE_INVALID');
  const {centerQ,scale:pixelScale,angleDegrees}=value,a=(angleDegrees%360)*Math.PI/180,ca=Math.cos(a),sa=Math.sin(a);
  const inverse=p=>{const dx=(p[0]-540)/pixelScale,dy=(p[1]-960)/pixelScale,qx=centerQ[0]+ca*dx+sa*dy,qy=centerQ[1]-sa*dx+ca*dy;return[c+qx/cos,lat-qy];};
  const corners=[[0,0],[1080,0],[1080,1920],[0,1920]].map(inverse);
  const envelope=[Math.min(...corners.map(p=>p[0])),Math.min(...corners.map(p=>p[1])),Math.max(...corners.map(p=>p[0])),Math.max(...corners.map(p=>p[1]))];
  if(!validGeoBounds(envelope))throw similarityError('SIMILARITY_GEOGRAPHIC_DOMAIN_OR_DATELINE_UNSUPPORTED');
  // Rotation cannot enlarge an AABB to evade the original closest-extent gate.
  const minimum=similarityMinimumBounds,initialMinimum=similarityInitialMinimumBounds,axisExtent=[1080/(pixelScale*cos),1920/pixelScale];
  if([minimum,initialMinimum].some(m=>axisExtent[0]<m[2]-m[0]-1e-9||axisExtent[1]<m[3]-m[1]-1e-9))throw similarityError('LOCAL_NOT_ADMITTED','Similarity exceeds the original admitted minimum camera extent');
  const qRadius=Math.hypot(540,960)/pixelScale,qMagnitude=Math.max(Math.abs(centerQ[0])+qRadius,Math.abs(centerQ[1])+qRadius),positionPrecisionPixels=4*float32HalfUlp(qMagnitude)*pixelScale;
  if(positionPrecisionPixels>.25)throw similarityError('SIMILARITY_FLOAT32_POSITION_PRECISION_EXCEEDED');
  const asset=similarityAsset,descriptor=terrainDetailDescriptor(asset),image=regional.image,dimensions=[image.naturalWidth??image.width,image.naturalHeight??image.height];
  if(!validGeoBounds(asset.bounds,true)||(asset.CRS??asset.source?.crs)!=='EPSG:4326'||asset.NoData!==null||!finitePoint(descriptor.pixelSpacing)||descriptor.pixelSpacing.some(v=>v<=0)||!/^[a-f0-9]{64}$/i.test(descriptor.nativeSourceSha256??'')||dimensions.some(v=>!Number.isSafeInteger(v)||v<2)||asset.dimensions&&(!finitePoint(asset.dimensions)||asset.dimensions.some((v,i)=>v!==dimensions[i])))throw similarityError('SIMILARITY_NATIVE_TERRAIN_DESCRIPTOR_REQUIRED');
  const spacing=descriptor.pixelSpacing.map((v,i)=>Math.max(v,(asset.bounds[i+2]-asset.bounds[i])/dimensions[i]));
  const density=[pixelScale*spacing[0]*cos,pixelScale*spacing[1]];
  if(Math.max(...density)>1+1e-8)throw similarityError('SIMILARITY_NATIVE_TEXEL_DENSITY_EXCEEDED');
  const gutter=Math.min((envelope[0]-asset.bounds[0])/spacing[0],(envelope[1]-asset.bounds[1])/spacing[1],(asset.bounds[2]-envelope[2])/spacing[0],(asset.bounds[3]-envelope[3])/spacing[1]);
  if(gutter<1-1e-8)throw similarityError('SIMILARITY_SOURCE_ENVELOPE_GUTTER_FAILED');
  similarityReady=false;
  camera.left=-540/pixelScale;camera.right=540/pixelScale;camera.top=960/pixelScale;camera.bottom=-960/pixelScale;
  camera.position.set(centerQ[0],-centerQ[1],5);camera.rotation.set(0,0,a);camera.updateProjectionMatrix();camera.updateMatrixWorld();
  const actual=sourceEnvelope();
  if(actual.corners.some((p,i)=>Math.hypot(p[0]-corners[i][0],p[1]-corners[i][1])>1e-7))throw similarityError('SIMILARITY_NATIVE_CAMERA_INVERSE_MISMATCH');
  uniforms.similarityCenterQ.value.set(...centerQ);uniforms.similarityScale.value=pixelScale;uniforms.similarityAngle.value.set(ca,sa);uniforms.similarityTileCenterUV.value.set(((c-asset.bounds[0])*cos+centerQ[0])/((asset.bounds[2]-asset.bounds[0])*cos),(lat-asset.bounds[1]-centerQ[1])/(asset.bounds[3]-asset.bounds[1]));uniforms.similarityEnabled.value=1;
  const footprint=(Math.abs(ca)+Math.abs(sa))/pixelScale;uniforms.canonicalPixelDegrees.value.set(footprint/cos,footprint);uniforms.bounds.value.set(...envelope);
  currentBounds=[...envelope];draw(idScene,camera,idTarget);draw(covScene,camera,covTarget);
  similarityState={schema:REFERENCE_SIMILARITY_SCHEMA,centerQ:[...centerQ],scale:pixelScale,angleDegrees,projection:projectionDescriptor(),sourceEnvelope:actual,sourceAdmission:{terrainSHA256:regional.userData.verifiedSimilaritySource.sha256,nativeSourceSHA256:descriptor.nativeSourceSha256,nativePixelSpacing:spacing,actualDecodedDimensions:dimensions,projectedPixelsPerNativeTexel:density,minimumSourceGutterPixels:gutter,minimumOriginalExtent:[...minimum],minimumPlanExtent:[...initialMinimum],positionPrecisionBoundPixels:positionPrecisionPixels,sourceSampling:'CPU_CENTER_RELATIVE_UV_PLUS_SMALL_GPU_INVERSE_DELTA',qualityPolicy:'NO_MORE_THAN_ONE_OUTPUT_PIXEL_PER_NATIVE_TEXEL_AND_ONE_NATIVE_PIXEL_GUTTER',actualTerrainBytesVerified:true},cameraLocked:false,settleLocked:false,completedFrameRotation:false,screenGraphicsPolicy:'CURRENT_PROJECTED_CONSUMER_REQUIRED_NATIVE_FIXED_GRAPHICS_DISABLED'};
  evidence.cameraFrame={...similarityState,bounds:[...currentBounds],anchorCanonical:screen(plan.anchor.coordinates),layoutFrozen:!!layoutPlan};
  similarityReady=true;return structuredClone(evidence.cameraFrame);
 }""")
replace("  const [west,south,east,north]=nextBounds;", """  if(similarityOptIn){camera.rotation.set(0,0,0);uniforms.similarityEnabled.value=0;similarityState=null;similarityReady=true;}
  const [west,south,east,north]=nextBounds;""")
replace("  if(contextTerrain&&uniforms.terrainLodWeight.value===1){", """  if(similarityOptIn&&!similarityReady)throw similarityError('SIMILARITY_PREVIOUS_UPDATE_FAILED_NO_DRAW_ALLOWED');
  if(similarityState&&graphics)throw similarityError('SIMILARITY_CURRENT_PROJECTED_GRAPHIC_CONSUMER_REQUIRED');
  if(similarityState&&uniforms.terrainLodWeight.value!==1)throw similarityError('SIMILARITY_SINGLE_QUALIFIED_TERRAIN_SOURCE_REQUIRED');
  if(similarityState&&dem){const corners=similarityState.sourceEnvelope.corners,p=heightSource?.pixelSpacing;if(!finitePoint(p)||p.some((v,i)=>v<=0||float32HalfUlp(Math.max(...corners.map(q=>Math.abs(q[i]))))>v*.25))throw similarityError('SIMILARITY_DEM_GEOGRAPHIC_PRECISION_INSUFFICIENT');}
  if(contextTerrain&&uniforms.terrainLodWeight.value===1){""")
replace(" return {render,renderFrame,updateCamera,setScaleVisual", " return {render,renderFrame,updateCamera,updateSimilarity,projectionDescriptor,inverseScreen,sourceEnvelope,setScaleVisual")

candidate=ns/'candidates/renderer.similarity.candidate04.mjs'
with candidate.open('x') as f:f.write(s)
patch=''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/world-simulation-shorts-engine/web/map_infographic_v1/renderer.mjs',tofile='b/world-simulation-shorts-engine/web/map_infographic_v1/renderer.mjs'))
with (ns/'candidates/renderer.similarity.proposed04.patch').open('x') as f:f.write(patch)
summary={'originalSHA256':hashlib.sha256(original.encode()).hexdigest(),'candidateSHA256':hashlib.sha256(s.encode()).hexdigest(),'originalBytes':len(original.encode()),'candidateBytes':len(s.encode()),'originalRendererModified':False,'onlyAuthorizedProtectedPath':str(source.relative_to(root)),'additionalLines':len(s.splitlines())-len(original.splitlines()),'schema':'REFERENCE_SIMILARITY_2D_V1','publicFactoryOptIn':"projectionMode:'REFERENCE_SIMILARITY_2D_V1'",'publicMethods':['updateSimilarity({centerQ,scale,angleDegrees})','projectionDescriptor()','inverseScreen(pixel)','sourceEnvelope()']}
with (ns/'candidates/PROPOSAL_SUMMARY04.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary))
